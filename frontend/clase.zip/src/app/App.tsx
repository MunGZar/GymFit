import { useState } from 'react';
import { Calendar, Users, TrendingUp, AlertCircle, ChevronLeft, ChevronRight, X, Plus } from 'lucide-react';
import Sidebar from './components/Sidebar';
import StatsCard from './components/StatsCard';
import ClassEventBlock from './components/ClassEventBlock';
import ClassDetailPanel from './components/ClassDetailPanel';
import NewClassModal from './components/NewClassModal';

interface ClassEvent {
  id: string;
  name: string;
  type: 'Spinning' | 'Yoga' | 'Funcional' | 'Zumba' | 'Crossfit';
  instructor: string;
  time: string;
  capacity: number;
  enrolled: number;
  day: string;
  duration: string;
  description?: string;
  participants: Array<{
    id: string;
    name: string;
    initials: string;
    plan: string;
  }>;
}

export default function App() {
  const [activeView, setActiveView] = useState<'calendar' | 'list'>('calendar');
  const [selectedClass, setSelectedClass] = useState<ClassEvent | null>(null);
  const [showNewClassModal, setShowNewClassModal] = useState(false);
  const [filterTrainer, setFilterTrainer] = useState('Todos');
  const [filterType, setFilterType] = useState('Todos');
  const [filterAvailability, setFilterAvailability] = useState('Todos');

  const classes: ClassEvent[] = [
    {
      id: '1',
      name: 'Spinning Matutino',
      type: 'Spinning',
      instructor: 'Juan Pérez',
      time: '6:00 AM',
      capacity: 15,
      enrolled: 8,
      day: 'Lunes',
      duration: '60 minutos',
      participants: [
        { id: '1', name: 'María González', initials: 'MG', plan: 'Premium' },
        { id: '2', name: 'Carlos Ruiz', initials: 'CR', plan: 'Básico' },
        { id: '3', name: 'Ana Martínez', initials: 'AM', plan: 'Premium' },
        { id: '4', name: 'Luis Fernández', initials: 'LF', plan: 'Básico' },
        { id: '5', name: 'Elena Torres', initials: 'ET', plan: 'Premium' },
        { id: '6', name: 'Diego Castro', initials: 'DC', plan: 'Básico' },
        { id: '7', name: 'Sofia Vargas', initials: 'SV', plan: 'Premium' },
        { id: '8', name: 'Miguel Sánchez', initials: 'MS', plan: 'Básico' },
      ]
    },
    {
      id: '2',
      name: 'Yoga',
      type: 'Yoga',
      instructor: 'Ana Gómez',
      time: '8:00 AM',
      capacity: 12,
      enrolled: 12,
      day: 'Lunes',
      duration: '60 minutos',
      participants: []
    },
    {
      id: '3',
      name: 'Funcional',
      type: 'Funcional',
      instructor: 'Carlos Ríos',
      time: '6:00 PM',
      capacity: 20,
      enrolled: 5,
      day: 'Lunes',
      duration: '60 minutos',
      participants: []
    },
    {
      id: '4',
      name: 'Crossfit',
      type: 'Crossfit',
      instructor: 'Juan Pérez',
      time: '7:00 AM',
      capacity: 20,
      enrolled: 18,
      day: 'Miércoles',
      duration: '60 minutos',
      participants: []
    },
    {
      id: '5',
      name: 'Zumba',
      type: 'Zumba',
      instructor: 'Ana Gómez',
      time: '5:00 PM',
      capacity: 15,
      enrolled: 10,
      day: 'Miércoles',
      duration: '60 minutos',
      participants: []
    },
    {
      id: '6',
      name: 'Spinning',
      type: 'Spinning',
      instructor: 'Juan Pérez',
      time: '6:00 AM',
      capacity: 15,
      enrolled: 3,
      day: 'Viernes',
      duration: '60 minutos',
      participants: []
    },
    {
      id: '7',
      name: 'Funcional',
      type: 'Funcional',
      instructor: 'Carlos Ríos',
      time: '7:00 AM',
      capacity: 20,
      enrolled: 15,
      day: 'Viernes',
      duration: '60 minutos',
      participants: []
    },
  ];

  const weekDays = [
    { name: 'Lunes', date: '22 Abr' },
    { name: 'Martes', date: '23 Abr' },
    { name: 'Miércoles', date: '24 Abr' },
    { name: 'Jueves', date: '25 Abr' },
    { name: 'Viernes', date: '26 Abr' },
    { name: 'Sábado', date: '27 Abr' },
  ];

  const getClassesForDay = (day: string) => {
    return classes.filter(c => c.day === day);
  };

  return (
    <div className="min-h-screen" style={{
      background: '#050508',
      fontFamily: 'Inter, sans-serif'
    }}>
      <Sidebar />

      <div className="ml-60 p-8">
        {/* Page Header */}
        <div className="flex items-start justify-between mb-8">
          <div>
            <h1 className="text-white mb-2" style={{
              fontFamily: 'Outfit, sans-serif',
              fontWeight: 800,
              fontSize: '28px'
            }}>
              Clases Grupales
            </h1>
            <p className="text-sm" style={{ color: '#94a3b8' }}>
              Programa y administra las actividades colectivas del gimnasio.
            </p>
          </div>
          <button
            onClick={() => setShowNewClassModal(true)}
            className="px-6 py-3 rounded-xl text-white font-semibold flex items-center gap-2"
            style={{
              background: 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)',
            }}
          >
            <Plus size={20} />
            Nueva Clase
          </button>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          <StatsCard
            icon={<Calendar size={20} />}
            label="Clases esta semana"
            value="12"
            iconColor="#00f2ff"
          />
          <StatsCard
            icon={<Users size={20} />}
            label="Cupos disponibles"
            value="47"
            iconColor="#7d2ae8"
          />
          <StatsCard
            icon={<TrendingUp size={20} />}
            label="Participantes hoy"
            value="28"
            iconColor="#00f2ff"
          />
          <StatsCard
            icon={<AlertCircle size={20} />}
            label="Clases llenas"
            value="3"
            iconColor="#ff3b3b"
          />
        </div>

        {/* View Toggle + Filters */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveView('calendar')}
              className={`px-6 py-2.5 rounded-xl font-medium transition-all ${
                activeView === 'calendar'
                  ? 'text-white'
                  : 'text-gray-400 hover:text-gray-300'
              }`}
              style={activeView === 'calendar' ? {
                background: 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)',
              } : {
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.08)'
              }}
            >
              Vista Calendario
            </button>
            <button
              onClick={() => setActiveView('list')}
              className={`px-6 py-2.5 rounded-xl font-medium transition-all ${
                activeView === 'list'
                  ? 'text-white'
                  : 'text-gray-400 hover:text-gray-300'
              }`}
              style={activeView === 'list' ? {
                background: 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)',
              } : {
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.08)'
              }}
            >
              Vista Lista
            </button>
          </div>

          <div className="flex gap-3">
            <select
              value={filterTrainer}
              onChange={(e) => setFilterTrainer(e.target.value)}
              className="px-4 py-2 rounded-xl text-white text-sm outline-none"
              style={{
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.08)'
              }}
            >
              <option value="Todos">Entrenador: Todos</option>
              <option value="Juan Pérez">Juan Pérez</option>
              <option value="Ana Gómez">Ana Gómez</option>
              <option value="Carlos Ríos">Carlos Ríos</option>
            </select>

            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-4 py-2 rounded-xl text-white text-sm outline-none"
              style={{
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.08)'
              }}
            >
              <option value="Todos">Tipo de clase: Todos</option>
              <option value="Spinning">Spinning</option>
              <option value="Yoga">Yoga</option>
              <option value="Funcional">Funcional</option>
              <option value="Zumba">Zumba</option>
              <option value="Crossfit">Crossfit</option>
            </select>

            <select
              value={filterAvailability}
              onChange={(e) => setFilterAvailability(e.target.value)}
              className="px-4 py-2 rounded-xl text-white text-sm outline-none"
              style={{
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.08)'
              }}
            >
              <option value="Todos">Disponibilidad: Todos</option>
              <option value="Con cupos">Con cupos</option>
              <option value="Llenas">Llenas</option>
            </select>
          </div>
        </div>

        {/* Calendar View */}
        {activeView === 'calendar' && (
          <div
            className="rounded-3xl p-6"
            style={{
              background: 'rgba(255,255,255,0.03)',
              border: '1px solid rgba(255,255,255,0.08)',
              backdropFilter: 'blur(12px)'
            }}
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <button className="p-2 rounded-lg text-gray-400 hover:text-white transition-colors">
                  <ChevronLeft size={20} />
                </button>
                <span className="text-white font-medium">22 - 27 Abril 2026</span>
                <button className="p-2 rounded-lg text-gray-400 hover:text-white transition-colors">
                  <ChevronRight size={20} />
                </button>
              </div>
              <button
                className="px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                style={{
                  color: '#00f2ff',
                  border: '1px solid rgba(0,242,255,0.3)'
                }}
              >
                Hoy
              </button>
            </div>

            <div className="grid grid-cols-6 gap-4">
              {weekDays.map((day) => (
                <div key={day.name}>
                  <div className="mb-3 text-center">
                    <div className="text-sm font-medium text-white">{day.name}</div>
                    <div className="text-xs" style={{ color: '#94a3b8' }}>{day.date}</div>
                  </div>
                  <div className="space-y-2">
                    {getClassesForDay(day.name).map((classEvent) => (
                      <ClassEventBlock
                        key={classEvent.id}
                        classEvent={classEvent}
                        onClick={() => setSelectedClass(classEvent)}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Class Detail Panel */}
      {selectedClass && (
        <ClassDetailPanel
          classEvent={selectedClass}
          onClose={() => setSelectedClass(null)}
        />
      )}

      {/* New Class Modal */}
      {showNewClassModal && (
        <NewClassModal onClose={() => setShowNewClassModal(false)} />
      )}
    </div>
  );
}
