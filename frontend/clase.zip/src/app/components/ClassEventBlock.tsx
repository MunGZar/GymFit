interface ClassEvent {
  id: string;
  name: string;
  type: 'Spinning' | 'Yoga' | 'Funcional' | 'Zumba' | 'Crossfit';
  instructor: string;
  time: string;
  capacity: number;
  enrolled: number;
}

interface ClassEventBlockProps {
  classEvent: ClassEvent;
  onClick: () => void;
}

const classTypeColors = {
  Spinning: '#00f2ff',
  Yoga: '#7d2ae8',
  Funcional: 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)',
  Zumba: '#e879f9',
  Crossfit: '#fb923c'
};

export default function ClassEventBlock({ classEvent, onClick }: ClassEventBlockProps) {
  const isFull = classEvent.enrolled >= classEvent.capacity;
  const isAlmostFull = classEvent.capacity - classEvent.enrolled < 3 && !isFull;
  const spotsLeft = classEvent.capacity - classEvent.enrolled;

  const borderColor = typeof classTypeColors[classEvent.type] === 'string'
    ? classTypeColors[classEvent.type]
    : '#00f2ff';

  return (
    <div
      onClick={onClick}
      className="p-3 rounded-xl cursor-pointer transition-all hover:brightness-125"
      style={{
        background: 'rgba(255,255,255,0.05)',
        border: '1px solid rgba(255,255,255,0.08)',
        borderLeft: `4px solid ${borderColor}`,
        backdropFilter: 'blur(8px)'
      }}
    >
      <div className="flex items-start justify-between mb-1.5">
        <div className="text-white font-semibold text-xs">{classEvent.time}</div>
        {isFull && (
          <span
            className="text-[9px] px-1.5 py-0.5 rounded font-bold uppercase"
            style={{
              background: '#ff3b3b',
              color: 'white'
            }}
          >
            LLENA
          </span>
        )}
      </div>
      <div className="text-white font-bold text-sm mb-1">{classEvent.name}</div>
      <div className="text-xs mb-2" style={{ color: '#94a3b8' }}>
        {classEvent.instructor}
      </div>
      <div
        className="text-[10px] px-2 py-1 rounded inline-block font-medium"
        style={{
          background: isFull
            ? 'rgba(255, 59, 59, 0.2)'
            : isAlmostFull
            ? 'rgba(251, 146, 60, 0.2)'
            : 'rgba(34, 197, 94, 0.2)',
          color: isFull
            ? '#ff3b3b'
            : isAlmostFull
            ? '#fb923c'
            : '#22c55e'
        }}
      >
        {classEvent.enrolled}/{classEvent.capacity} cupos
      </div>
    </div>
  );
}
