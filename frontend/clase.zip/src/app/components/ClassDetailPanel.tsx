import { X, Clock, Users, CheckCircle } from 'lucide-react';

interface ClassEvent {
  id: string;
  name: string;
  type: 'Spinning' | 'Yoga' | 'Funcional' | 'Zumba' | 'Crossfit';
  instructor: string;
  time: string;
  capacity: number;
  enrolled: number;
  day: string;
  duration: string;
  description?: string;
  participants: Array<{
    id: string;
    name: string;
    initials: string;
    plan: string;
  }>;
}

interface ClassDetailPanelProps {
  classEvent: ClassEvent;
  onClose: () => void;
}

const classTypeColors = {
  Spinning: '#00f2ff',
  Yoga: '#7d2ae8',
  Funcional: 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)',
  Zumba: '#e879f9',
  Crossfit: '#fb923c'
};

export default function ClassDetailPanel({ classEvent, onClose }: ClassDetailPanelProps) {
  const isFull = classEvent.enrolled >= classEvent.capacity;
  const fillPercentage = (classEvent.enrolled / classEvent.capacity) * 100;

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 z-40"
        style={{ background: 'rgba(0,0,0,0.6)' }}
        onClick={onClose}
      />

      {/* Panel */}
      <div
        className="fixed right-0 top-0 h-screen w-[360px] z-50 p-6 overflow-y-auto"
        style={{
          background: 'rgba(5,5,8,0.95)',
          border: '1px solid rgba(255,255,255,0.08)',
          backdropFilter: 'blur(20px)'
        }}
      >
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div>
            <h2
              className="text-white mb-2"
              style={{
                fontFamily: 'Outfit, sans-serif',
                fontWeight: 800,
                fontSize: '22px'
              }}
            >
              {classEvent.name}
            </h2>
            <span
              className="inline-block px-3 py-1 rounded-full text-xs font-semibold"
              style={{
                background: typeof classTypeColors[classEvent.type] === 'string'
                  ? `${classTypeColors[classEvent.type]}20`
                  : 'rgba(0,242,255,0.2)',
                color: typeof classTypeColors[classEvent.type] === 'string'
                  ? classTypeColors[classEvent.type]
                  : '#00f2ff'
              }}
            >
              {classEvent.type}
            </span>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {/* Class Info */}
        <div className="space-y-4 mb-6">
          <div className="flex items-center gap-3">
            <div
              className="w-12 h-12 rounded-full flex items-center justify-center font-semibold"
              style={{
                background: 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)',
                color: 'white'
              }}
            >
              {classEvent.instructor.split(' ').map(n => n[0]).join('')}
            </div>
            <div>
              <div className="text-xs" style={{ color: '#94a3b8' }}>Instructor</div>
              <div className="text-white font-medium">{classEvent.instructor}</div>
            </div>
          </div>

          <div>
            <div className="text-xs mb-1" style={{ color: '#94a3b8' }}>Horario</div>
            <div className="text-white font-medium">
              {classEvent.day} · {classEvent.time} — {calculateEndTime(classEvent.time, classEvent.duration)}
            </div>
          </div>

          <div>
            <div className="text-xs mb-1" style={{ color: '#94a3b8' }}>Duración</div>
            <div className="text-white font-medium flex items-center gap-2">
              <Clock size={16} />
              {classEvent.duration}
            </div>
          </div>

          <div>
            <div className="text-xs mb-2" style={{ color: '#94a3b8' }}>Capacidad</div>
            <div className="w-full h-2 rounded-full overflow-hidden mb-2" style={{ background: 'rgba(255,255,255,0.1)' }}>
              <div
                className="h-full transition-all"
                style={{
                  width: `${fillPercentage}%`,
                  background: '#00f2ff'
                }}
              />
            </div>
            <div className="text-sm text-white">
              {classEvent.enrolled} de {classEvent.capacity} cupos ocupados
            </div>
          </div>

          <div>
            <div className="text-xs mb-1" style={{ color: '#94a3b8' }}>Estado</div>
            <span
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold"
              style={{
                background: isFull ? 'rgba(255, 59, 59, 0.2)' : 'rgba(34, 197, 94, 0.2)',
                color: isFull ? '#ff3b3b' : '#22c55e'
              }}
            >
              {isFull ? 'Llena' : 'Disponible'}
            </span>
          </div>
        </div>

        {/* Participants List */}
        {classEvent.participants.length > 0 && (
          <div className="mb-6">
            <div className="text-sm font-semibold mb-3" style={{ color: '#94a3b8' }}>
              Participantes inscritos
            </div>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {classEvent.participants.map((participant) => (
                <div
                  key={participant.id}
                  className="flex items-center justify-between p-3 rounded-xl"
                  style={{
                    background: 'rgba(255,255,255,0.03)',
                    border: '1px solid rgba(255,255,255,0.08)'
                  }}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold"
                      style={{
                        background: 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)',
                        color: 'white'
                      }}
                    >
                      {participant.initials}
                    </div>
                    <div>
                      <div className="text-white text-sm">{participant.name}</div>
                      <span
                        className="text-[10px] px-1.5 py-0.5 rounded"
                        style={{
                          background: 'rgba(125, 42, 232, 0.2)',
                          color: '#7d2ae8'
                        }}
                      >
                        {participant.plan}
                      </span>
                    </div>
                  </div>
                  <button className="text-red-400 hover:text-red-300 transition-colors">
                    <X size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="space-y-3">
          <button
            className="w-full px-6 py-3 rounded-xl text-white font-semibold"
            style={{
              background: 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)',
            }}
          >
            Inscribir Socio
          </button>
          <button
            className="w-full px-6 py-3 rounded-xl font-semibold transition-all"
            style={{
              color: '#00f2ff',
              border: '1px solid rgba(0,242,255,0.3)',
              background: 'transparent'
            }}
          >
            Editar Clase
          </button>
          <button
            className="w-full px-6 py-3 rounded-xl font-semibold transition-all"
            style={{
              color: '#ff3b3b',
              border: '1px solid rgba(255,59,59,0.3)',
              background: 'transparent'
            }}
          >
            Cancelar Clase
          </button>
        </div>
      </div>
    </>
  );
}

function calculateEndTime(startTime: string, duration: string): string {
  const minutes = parseInt(duration.split(' ')[0]);
  const [time, period] = startTime.split(' ');
  const [hours, mins] = time.split(':').map(Number);

  let totalMinutes = hours * 60 + mins + minutes;
  let endHours = Math.floor(totalMinutes / 60) % 12 || 12;
  let endMins = totalMinutes % 60;

  return `${endHours}:${endMins.toString().padStart(2, '0')} ${period}`;
}
