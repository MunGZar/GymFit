interface StatsCardProps {
  icon: React.ReactNode;
  label: string;
  value: string;
  iconColor: string;
}

export default function StatsCard({ icon, label, value, iconColor }: StatsCardProps) {
  return (
    <div
      className="p-5 rounded-2xl"
      style={{
        background: 'rgba(255,255,255,0.03)',
        border: '1px solid rgba(255,255,255,0.08)',
        backdropFilter: 'blur(12px)'
      }}
    >
      <div className="flex items-start justify-between mb-3">
        <div
          className="p-2.5 rounded-xl"
          style={{
            color: iconColor,
            background: `${iconColor}15`,
            boxShadow: `0 0 20px ${iconColor}30`
          }}
        >
          {icon}
        </div>
      </div>
      <div className="text-xs uppercase tracking-wide mb-2" style={{ color: '#94a3b8' }}>
        {label}
      </div>
      <div
        className="text-white"
        style={{
          fontFamily: 'Outfit, sans-serif',
          fontWeight: 800,
          fontSize: '28px',
          lineHeight: 1
        }}
      >
        {value}
      </div>
    </div>
  );
}
