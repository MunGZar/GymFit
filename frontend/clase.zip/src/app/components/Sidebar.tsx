import { Home, Users, Calendar, Dumbbell, Settings, BarChart3 } from 'lucide-react';

export default function Sidebar() {
  const navItems = [
    { icon: <Home size={20} />, label: 'Dashboard', active: false },
    { icon: <Users size={20} />, label: 'Socios', active: false },
    { icon: <Calendar size={20} />, label: 'Clases', active: true },
    { icon: <Dumbbell size={20} />, label: 'Equipamiento', active: false },
    { icon: <BarChart3 size={20} />, label: 'Reportes', active: false },
    { icon: <Settings size={20} />, label: 'Configuración', active: false },
  ];

  return (
    <div
      className="fixed left-0 top-0 h-screen w-60 p-6 flex flex-col"
      style={{
        background: 'rgba(255,255,255,0.03)',
        borderRight: '1px solid rgba(255,255,255,0.08)',
        backdropFilter: 'blur(12px)'
      }}
    >
      {/* Logo */}
      <div className="mb-10">
        <div
          className="text-2xl font-extrabold mb-1"
          style={{
            fontFamily: 'Outfit, sans-serif',
            background: 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text'
          }}
        >
          GymFit
        </div>
        <div className="text-xs tracking-wide" style={{ color: '#94a3b8' }}>
          FIT-CONTROL
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-2">
        {navItems.map((item) => (
          <button
            key={item.label}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
              item.active ? 'text-white' : 'text-gray-400 hover:text-gray-300'
            }`}
            style={item.active ? {
              background: 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)',
            } : {}}
          >
            {item.icon}
            <span className="font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      {/* User Profile */}
      <div
        className="mt-auto p-4 rounded-xl flex items-center gap-3"
        style={{
          background: 'rgba(255,255,255,0.03)',
          border: '1px solid rgba(255,255,255,0.08)'
        }}
      >
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center font-semibold text-sm"
          style={{
            background: 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)',
            color: 'white'
          }}
        >
          AD
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-white text-sm font-medium truncate">Admin</div>
          <div className="text-xs truncate" style={{ color: '#94a3b8' }}>admin@gymfit.com</div>
        </div>
      </div>
    </div>
  );
}
