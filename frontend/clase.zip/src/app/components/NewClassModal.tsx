import { X } from 'lucide-react';
import { useState } from 'react';

interface NewClassModalProps {
  onClose: () => void;
}

const classTypes = [
  { name: 'Spinning', color: '#00f2ff' },
  { name: 'Yoga', color: '#7d2ae8' },
  { name: 'Funcional', color: '#00f2ff' },
  { name: 'Zumba', color: '#e879f9' },
  { name: 'Crossfit', color: '#fb923c' }
];

const trainers = [
  'Juan Pérez',
  'Ana Gómez',
  'Carlos Ríos'
];

const weekDays = [
  { label: 'L', value: 'Lunes' },
  { label: 'M', value: 'Martes' },
  { label: 'X', value: 'Miércoles' },
  { label: 'J', value: 'Jueves' },
  { label: 'V', value: 'Viernes' },
  { label: 'S', value: 'Sábado' },
  { label: 'D', value: 'Domingo' }
];

export default function NewClassModal({ onClose }: NewClassModalProps) {
  const [selectedDays, setSelectedDays] = useState<string[]>([]);

  const toggleDay = (day: string) => {
    setSelectedDays(prev =>
      prev.includes(day)
        ? prev.filter(d => d !== day)
        : [...prev, day]
    );
  };

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 z-50 flex items-center justify-center"
        style={{ background: 'rgba(0,0,0,0.6)' }}
        onClick={onClose}
      >
        {/* Modal */}
        <div
          className="w-full max-w-[500px] p-6 rounded-3xl"
          style={{
            background: 'rgba(5,5,8,0.95)',
            border: '1px solid rgba(255,255,255,0.08)',
            backdropFilter: 'blur(20px)'
          }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-start justify-between mb-6">
            <h2
              className="text-white"
              style={{
                fontFamily: 'Outfit, sans-serif',
                fontWeight: 800,
                fontSize: '20px'
              }}
            >
              Programar Nueva Clase
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <X size={24} />
            </button>
          </div>

          {/* Form */}
          <form className="space-y-4">
            {/* Class Name */}
            <div>
              <label className="block text-sm mb-2" style={{ color: '#94a3b8' }}>
                Nombre de la clase
              </label>
              <input
                type="text"
                placeholder="Ej: Spinning Matutino"
                className="w-full px-4 py-3 rounded-xl text-white outline-none"
                style={{
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.08)'
                }}
              />
            </div>

            {/* Class Type */}
            <div>
              <label className="block text-sm mb-2" style={{ color: '#94a3b8' }}>
                Tipo de clase
              </label>
              <select
                className="w-full px-4 py-3 rounded-xl text-white outline-none"
                style={{
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.08)'
                }}
              >
                <option value="">Seleccionar tipo</option>
                {classTypes.map((type) => (
                  <option key={type.name} value={type.name}>
                    {type.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Trainer */}
            <div>
              <label className="block text-sm mb-2" style={{ color: '#94a3b8' }}>
                Entrenador responsable
              </label>
              <select
                className="w-full px-4 py-3 rounded-xl text-white outline-none"
                style={{
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.08)'
                }}
              >
                <option value="">Seleccionar entrenador</option>
                {trainers.map((trainer) => (
                  <option key={trainer} value={trainer}>
                    {trainer}
                  </option>
                ))}
              </select>
            </div>

            {/* Days of Week */}
            <div>
              <label className="block text-sm mb-2" style={{ color: '#94a3b8' }}>
                Días de la semana
              </label>
              <div className="flex gap-2">
                {weekDays.map((day) => (
                  <button
                    key={day.value}
                    type="button"
                    onClick={() => toggleDay(day.value)}
                    className={`flex-1 py-2 rounded-xl text-sm font-semibold transition-all ${
                      selectedDays.includes(day.value) ? 'text-white' : 'text-gray-400'
                    }`}
                    style={selectedDays.includes(day.value) ? {
                      background: 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)',
                    } : {
                      background: 'rgba(255,255,255,0.05)',
                      border: '1px solid rgba(255,255,255,0.08)'
                    }}
                  >
                    {day.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Time Range */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm mb-2" style={{ color: '#94a3b8' }}>
                  Hora de inicio
                </label>
                <input
                  type="time"
                  className="w-full px-4 py-3 rounded-xl text-white outline-none"
                  style={{
                    background: 'rgba(255,255,255,0.05)',
                    border: '1px solid rgba(255,255,255,0.08)'
                  }}
                />
              </div>
              <div>
                <label className="block text-sm mb-2" style={{ color: '#94a3b8' }}>
                  Hora de fin
                </label>
                <input
                  type="time"
                  className="w-full px-4 py-3 rounded-xl text-white outline-none"
                  style={{
                    background: 'rgba(255,255,255,0.05)',
                    border: '1px solid rgba(255,255,255,0.08)'
                  }}
                />
              </div>
            </div>

            {/* Capacity */}
            <div>
              <label className="block text-sm mb-2" style={{ color: '#94a3b8' }}>
                Capacidad máxima
              </label>
              <input
                type="number"
                placeholder="15"
                className="w-full px-4 py-3 rounded-xl text-white outline-none"
                style={{
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.08)'
                }}
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm mb-2" style={{ color: '#94a3b8' }}>
                Descripción opcional
              </label>
              <textarea
                rows={2}
                placeholder="Descripción de la clase..."
                className="w-full px-4 py-3 rounded-xl text-white outline-none resize-none"
                style={{
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.08)'
                }}
              />
            </div>

            {/* Buttons */}
            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-6 py-3 rounded-xl font-semibold transition-colors"
                style={{
                  color: '#94a3b8',
                  border: '1px solid rgba(255,255,255,0.08)',
                  background: 'transparent'
                }}
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="flex-1 px-6 py-3 rounded-xl text-white font-bold"
                style={{
                  background: 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)',
                }}
              >
                Programar Clase
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
}
