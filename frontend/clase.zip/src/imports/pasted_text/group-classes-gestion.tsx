Design a dark-themed full-screen page for a gym management system called
"GymFit" (FIT-CONTROL). This is the "Gestión de Clases Grupales" module
where administrators create and manage group classes and members can
reserve their spots.

Visual style:
- Dark background: #050508
- Primary accent: #00f2ff (cyan)
- Secondary accent: #7d2ae8 (violet/purple)
- Gradient: linear 135deg from #00f2ff to #7d2ae8
- Glassmorphism cards: background rgba(255,255,255,0.03), border 1px
  rgba(255,255,255,0.08), border-radius 20px, backdrop-filter blur 12px
- Body font: Inter (400, 500, 600)
- Heading font: Outfit (800)
- Text primary: #ffffff
- Text muted: #94a3b8

Layout:
Same fixed left sidebar (240px) with GymFit gradient logo and nav items.
"Clases" is the active nav item.

Main content area:

1. PAGE HEADER
Left: title "Clases Grupales" (Outfit 800, 28px, white).
Subtitle muted: "Programa y administra las actividades colectivas 
del gimnasio."
Right: gradient CTA button "+ Nueva Clase" (cyan-to-violet,
border-radius 12px).

2. TOP STATS ROW (4 small metric cards, glassmorphism)
- Clases esta semana: 12
- Cupos disponibles: 47
- Participantes hoy: 28
- Clases llenas: 3
Each card: small gradient icon, muted label 11px uppercase,
white large number Outfit 800, subtle glow on icon.

3. VIEW TOGGLE + FILTERS BAR
Left side: two toggle buttons to switch view —
"Vista Calendario" and "Vista Lista" 
(active toggle has gradient background, inactive is ghost).
Right side filter pills:
- Dropdown "Entrenador" — Todos / names
- Dropdown "Tipo de clase" — Todos / Yoga / Spinning / 
  Funcional / Zumba / Crossfit
- Dropdown "Disponibilidad" — Todos / Con cupos / Llenas

4. CALENDAR VIEW (shown as active, full width glassmorphism card)
A weekly calendar grid showing Monday to Saturday current week.
Header row: day names + dates (muted small text).
Each day column shows class event blocks:

Monday column example events:
- 6:00 AM — "Spinning" block (cyan background, semi-transparent)
  Instructor: "Juan Pérez" · 8/15 cupos
- 8:00 AM — "Yoga" block (violet background, semi-transparent)  
  Instructor: "Ana Gómez" · 12/12 cupos (LLENA badge in red)
- 6:00 PM — "Funcional" block (gradient background)
  Instructor: "Carlos Ríos" · 5/20 cupos

Wednesday column:
- 7:00 AM — "Crossfit" block (amber/orange tinted)
  Instructor: "Juan Pérez" · 18/20 cupos
- 5:00 PM — "Zumba" block (pink/violet tinted)
  Instructor: "Ana Gómez" · 10/15 cupos

Friday column:
- 6:00 AM — "Spinning" block (cyan)
  Instructor: "Juan Pérez" · 3/15 cupos
- 7:00 AM — "Funcional" block (gradient)
  Instructor: "Carlos Ríos" · 15/20 cupos

Each event block:
- Colored left border (4px) matching class type color
- Class name bold white 13px
- Instructor name muted 11px
- Capacity pill: "X/Y cupos" — green if available, 
  red if full, amber if almost full (<3 spots)
- On hover: slightly brighter background + cursor pointer

Navigation arrows left/right to move between weeks.
"Hoy" ghost button to return to current week.

5. CLASS DETAIL PANEL (shown as right side drawer, 360px wide)
Triggered by clicking a class event block on the calendar.
Slides in from the right over the calendar with dark overlay.
Glassmorphism panel with blur 20px.

Panel header:
- Class name: "Spinning Matutino" (Outfit 800, 22px, white)
- Type badge: "Spinning" in cyan pill
- Close X button top-right (muted)

Class info section:
- Instructor: avatar circle + "Juan Pérez" 
- Horario: "Lunes · 6:00 AM — 7:00 AM"
- Duración: "60 minutos"
- Capacidad: progress bar showing 8/15 filled
  (cyan fill, muted track, "8 de 15 cupos ocupados" label)
- Estado: "Disponible" green pill

Participants list:
Title: "Participantes inscritos" (Inter 600, 14px, muted)
Scrollable list of 8 registered members:
Each row: avatar circle with initials (gradient) + name (white 13px)
+ plan badge (tiny pill) + red X button to remove (admin only).

Bottom action buttons (full width, stacked):
- "Inscribir Socio" — gradient cyan-to-violet button
- "Editar Clase" — ghost button cyan border
- "Cancelar Clase" — ghost button red border

6. MODAL — "Nueva Clase Grupal" (show as open overlay)
Centered modal (max-width 500px), glassmorphism, blur 20px.
Title: "Programar Nueva Clase" (Outfit 800, 20px, white).

Form fields:
- Nombre de la clase (text input)
  placeholder: "Ej: Spinning Matutino"
- Tipo de clase (select with colored dot indicators):
  Spinning (cyan) / Yoga (violet) / Funcional (gradient) /
  Zumba (pink) / Crossfit (amber)
- Entrenador responsable (select dropdown with trainer avatars)
- Días de la semana (multi-select toggle buttons for each day:
  L M X J V S D — active days highlighted with gradient background,
  inactive are ghost dark pills)
- Hora de inicio (time input)
- Hora de fin (time input)
- Capacidad máxima (number input with person icon prefix)
- Descripción opcional (textarea, 2 rows)

Bottom buttons: "Cancelar" (ghost muted) and "Programar Clase"
(gradient cyan-to-violet, font-weight 700).
Dark overlay behind: rgba(0,0,0,0.6).

7. MEMBER VIEW — Inscripción a Clases (secondary state)
Show as a small reference panel at bottom or as a note:
When the logged user is a "Socio", the "+ Nueva Clase" button 
is hidden, edit/remove controls are hidden, and the class detail
panel shows instead a single CTA button:
"Reservar mi cupo" (gradient, full width) if available, or
"Clase llena — Unirme a lista de espera" (amber ghost) if full.
Membership validation badge shown: "Membresía activa requerida ✓"
in small green text below the button.