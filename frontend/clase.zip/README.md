
  # .

  This is a code bundle for .. The original project is available at https://www.figma.com/design/ttehRWXgolvFUnJ5Gb2QWa/..

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  