
  # Design GymFit Access Control Page

  This is a code bundle for Design GymFit Access Control Page. The original project is available at https://www.figma.com/design/0ZW4bH10OKlCmZdwZVQw22/Design-GymFit-Access-Control-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  