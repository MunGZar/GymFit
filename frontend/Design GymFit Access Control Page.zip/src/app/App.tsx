import { useState, useEffect } from 'react';
import { Search, QrCode, CheckCircle, XCircle, User, Clock } from 'lucide-react';

// Mock data for activity feed
const recentAccess = [
  { id: 1, name: 'Carlos Andrés Ruiz', plan: 'Premium', time: 'hace 2 min', allowed: true, initials: 'CR' },
  { id: 2, name: 'María Fernanda López', plan: 'Básico', time: 'hace 5 min', allowed: false, initials: 'ML' },
  { id: 3, name: 'Juan David Morales', plan: 'Premium', time: 'hace 8 min', allowed: true, initials: 'JM' },
  { id: 4, name: 'Ana Carolina Gómez', plan: 'Mensual', time: 'hace 12 min', allowed: true, initials: 'AG' },
  { id: 5, name: 'Diego Alejandro Castro', plan: 'Premium', time: 'hace 15 min', allowed: true, initials: 'DC' },
  { id: 6, name: 'Valentina Restrepo Silva', plan: 'Básico', time: 'hace 18 min', allowed: true, initials: 'VR' },
  { id: 7, name: 'Santiago Pérez Duarte', plan: 'Premium', time: 'hace 22 min', allowed: true, initials: 'SP' },
  { id: 8, name: 'Camila Andrea Torres', plan: 'Mensual', time: 'hace 25 min', allowed: true, initials: 'CT' },
  { id: 9, name: 'Andrés Felipe Vargas', plan: 'Premium', time: 'hace 30 min', allowed: true, initials: 'AV' },
  { id: 10, name: 'Laura Sofía Ramírez', plan: 'Básico', time: 'hace 35 min', allowed: true, initials: 'LR' },
];

export default function App() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showPermitted, setShowPermitted] = useState(true);
  const [showDenied, setShowDenied] = useState(true);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    };
    const dateStr = date.toLocaleDateString('es-CO', options);
    const capitalizedDate = dateStr.charAt(0).toUpperCase() + dateStr.slice(1);
    const time = date.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' });
    return `${capitalizedDate} — ${time}`;
  };

  const navItems = [
    { name: 'Dashboard', active: false },
    { name: 'Control de Acceso', active: true },
    { name: 'Socios', active: false },
    { name: 'Planes', active: false },
    { name: 'Entrenadores', active: false },
    { name: 'Reportes', active: false },
  ];

  return (
    <div style={{ fontFamily: 'Inter, sans-serif', backgroundColor: '#050508', minHeight: '100vh', color: '#ffffff' }}>
      <div className="flex h-screen">
        {/* Left Sidebar */}
        <aside style={{ width: '240px', backgroundColor: 'rgba(255,255,255,0.02)', borderRight: '1px solid rgba(255,255,255,0.08)' }} className="flex flex-col">
          {/* Logo */}
          <div className="p-6">
            <div style={{
              fontFamily: 'Outfit, sans-serif',
              background: 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text'
            }} className="text-2xl">
              GymFit
            </div>
            <div style={{ color: '#94a3b8', fontSize: '11px', marginTop: '4px' }}>FIT-CONTROL</div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-3">
            {navItems.map((item) => (
              <div
                key={item.name}
                style={{
                  padding: '12px 16px',
                  borderRadius: '12px',
                  marginBottom: '4px',
                  cursor: 'pointer',
                  background: item.active ? 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)' : 'transparent',
                  color: item.active ? '#ffffff' : '#94a3b8',
                  transition: 'all 0.2s'
                }}
              >
                {item.name}
              </div>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-auto">
          <div className="p-8">
            {/* Header */}
            <div className="flex justify-between items-start mb-8">
              <div>
                <h1 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '28px' }}>Control de Acceso</h1>
                <p style={{ color: '#94a3b8', fontSize: '14px', marginTop: '4px' }}>
                  Valida el ingreso de socios en tiempo real.
                </p>
              </div>
              <div style={{ color: '#94a3b8', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Clock size={16} />
                {formatTime(currentTime)}
              </div>
            </div>

            {/* Two Column Layout */}
            <div className="flex gap-6">
              {/* LEFT COLUMN - Access Validator Panel */}
              <div style={{ flex: '0 0 55%' }}>
                {/* Search Panel */}
                <div
                  style={{
                    background: 'rgba(255,255,255,0.03)',
                    border: '1px solid rgba(255,255,255,0.08)',
                    borderRadius: '20px',
                    backdropFilter: 'blur(12px)',
                    padding: '32px',
                    marginBottom: '24px'
                  }}
                >
                  <div className="relative">
                    <div className="absolute left-6 top-1/2 -translate-y-1/2">
                      <Search size={24} style={{ color: '#00f2ff' }} />
                    </div>
                    <input
                      type="text"
                      placeholder="Ingresa el número de identificación..."
                      style={{
                        width: '100%',
                        background: 'rgba(255,255,255,0.05)',
                        border: '2px solid #00f2ff',
                        borderRadius: '16px',
                        padding: '20px 24px 20px 64px',
                        fontSize: '20px',
                        color: '#ffffff',
                        outline: 'none',
                        boxShadow: '0 0 20px rgba(0,242,255,0.3)'
                      }}
                    />
                  </div>

                  {/* Helper Options */}
                  <div className="flex gap-3 mt-4">
                    <button
                      style={{
                        background: 'transparent',
                        border: '1px solid rgba(255,255,255,0.15)',
                        borderRadius: '20px',
                        padding: '8px 16px',
                        fontSize: '13px',
                        color: '#94a3b8',
                        cursor: 'pointer'
                      }}
                    >
                      Buscar por nombre
                    </button>
                    <button
                      style={{
                        background: 'transparent',
                        border: '1px solid rgba(255,255,255,0.15)',
                        borderRadius: '20px',
                        padding: '8px 16px',
                        fontSize: '13px',
                        color: '#94a3b8',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px'
                      }}
                    >
                      <QrCode size={14} />
                      Escanear QR
                    </button>
                  </div>

                  {/* Validate Button */}
                  <button
                    style={{
                      width: '100%',
                      background: 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)',
                      border: 'none',
                      borderRadius: '14px',
                      padding: '18px',
                      fontSize: '16px',
                      color: '#ffffff',
                      cursor: 'pointer',
                      marginTop: '20px'
                    }}
                  >
                    Validar Acceso
                  </button>
                </div>

                {/* Access Result Cards */}
                <div className="space-y-4">
                  {/* ACCESO PERMITIDO */}
                  {showPermitted && (
                    <div
                      style={{
                        background: 'rgba(255,255,255,0.03)',
                        border: '1px solid rgba(255,255,255,0.08)',
                        borderLeft: '4px solid #22c55e',
                        borderRadius: '20px',
                        backdropFilter: 'blur(12px)',
                        padding: '32px',
                        boxShadow: '0 0 30px rgba(34,197,94,0.15)',
                        position: 'relative'
                      }}
                    >
                      <button
                        onClick={() => setShowPermitted(false)}
                        style={{
                          position: 'absolute',
                          top: '16px',
                          right: '16px',
                          background: 'transparent',
                          border: 'none',
                          color: '#94a3b8',
                          cursor: 'pointer',
                          fontSize: '20px'
                        }}
                      >
                        ×
                      </button>

                      <div className="flex flex-col items-center mb-4">
                        <div
                          style={{
                            width: '80px',
                            height: '80px',
                            borderRadius: '50%',
                            background: 'rgba(34,197,94,0.2)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            marginBottom: '16px'
                          }}
                        >
                          <CheckCircle size={48} style={{ color: '#22c55e' }} />
                        </div>
                        <h3 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '24px', marginBottom: '12px' }}>
                          Carlos Andrés Ruiz
                        </h3>
                        <div className="flex gap-2">
                          <span
                            style={{
                              background: 'rgba(0,242,255,0.15)',
                              color: '#00f2ff',
                              padding: '4px 12px',
                              borderRadius: '12px',
                              fontSize: '12px'
                            }}
                          >
                            Premium
                          </span>
                          <span
                            style={{
                              background: 'rgba(34,197,94,0.15)',
                              color: '#22c55e',
                              padding: '4px 12px',
                              borderRadius: '12px',
                              fontSize: '12px'
                            }}
                          >
                            Membresía Activa
                          </span>
                        </div>
                      </div>

                      <div style={{ color: '#94a3b8', fontSize: '13px', textAlign: 'center', marginBottom: '8px' }}>
                        Vence: 15 de mayo 2026
                      </div>
                      <div style={{ color: '#94a3b8', fontSize: '12px', textAlign: 'center', marginBottom: '20px' }}>
                        Entrenador: Juan Pérez
                      </div>

                      <div
                        style={{
                          background: 'rgba(34,197,94,0.1)',
                          border: '1px solid rgba(34,197,94,0.3)',
                          borderRadius: '12px',
                          padding: '16px',
                          textAlign: 'center',
                          marginBottom: '12px'
                        }}
                      >
                        <div style={{ color: '#22c55e', letterSpacing: '2px', fontSize: '14px' }}>
                          ✓ ACCESO PERMITIDO
                        </div>
                      </div>

                      <div style={{ color: '#94a3b8', fontSize: '11px', textAlign: 'center' }}>
                        Ingreso registrado: {currentTime.toLocaleTimeString('es-CO')}
                      </div>
                    </div>
                  )}

                  {/* ACCESO DENEGADO */}
                  {showDenied && (
                    <div
                      style={{
                        background: 'rgba(255,255,255,0.03)',
                        border: '1px solid rgba(255,255,255,0.08)',
                        borderLeft: '4px solid #ef4444',
                        borderRadius: '20px',
                        backdropFilter: 'blur(12px)',
                        padding: '32px',
                        boxShadow: '0 0 30px rgba(239,68,68,0.15)',
                        position: 'relative'
                      }}
                    >
                      <button
                        onClick={() => setShowDenied(false)}
                        style={{
                          position: 'absolute',
                          top: '16px',
                          right: '16px',
                          background: 'transparent',
                          border: 'none',
                          color: '#94a3b8',
                          cursor: 'pointer',
                          fontSize: '20px'
                        }}
                      >
                        ×
                      </button>

                      <div className="flex flex-col items-center mb-4">
                        <div
                          style={{
                            width: '80px',
                            height: '80px',
                            borderRadius: '50%',
                            background: 'rgba(239,68,68,0.2)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            marginBottom: '16px'
                          }}
                        >
                          <XCircle size={48} style={{ color: '#ef4444' }} />
                        </div>
                        <h3 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '24px', marginBottom: '12px' }}>
                          María Fernanda López
                        </h3>
                        <div className="flex gap-2">
                          <span
                            style={{
                              background: 'rgba(148,163,184,0.15)',
                              color: '#94a3b8',
                              padding: '4px 12px',
                              borderRadius: '12px',
                              fontSize: '12px'
                            }}
                          >
                            Básico
                          </span>
                          <span
                            style={{
                              background: 'rgba(239,68,68,0.15)',
                              color: '#ef4444',
                              padding: '4px 12px',
                              borderRadius: '12px',
                              fontSize: '12px'
                            }}
                          >
                            Membresía Vencida
                          </span>
                        </div>
                      </div>

                      <div style={{ color: '#ef4444', fontSize: '13px', textAlign: 'center', marginBottom: '20px' }}>
                        Venció: 10 de abril 2026
                      </div>

                      <div
                        style={{
                          background: 'rgba(239,68,68,0.1)',
                          border: '1px solid rgba(239,68,68,0.3)',
                          borderRadius: '12px',
                          padding: '16px',
                          textAlign: 'center',
                          marginBottom: '12px'
                        }}
                      >
                        <div style={{ color: '#ef4444', letterSpacing: '2px', fontSize: '14px' }}>
                          ✗ ACCESO DENEGADO
                        </div>
                      </div>

                      <div style={{ color: '#94a3b8', fontSize: '11px', textAlign: 'center', marginBottom: '16px' }}>
                        Sugiere renovar la membresía en recepción.
                      </div>

                      <button
                        style={{
                          width: '100%',
                          background: 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)',
                          border: 'none',
                          borderRadius: '12px',
                          padding: '12px',
                          fontSize: '14px',
                          color: '#ffffff',
                          cursor: 'pointer'
                        }}
                      >
                        Renovar Membresía
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* RIGHT COLUMN - Today's Activity Feed */}
              <div style={{ flex: '0 0 45%' }}>
                {/* Header */}
                <div className="flex justify-between items-center mb-4">
                  <h2 style={{ fontSize: '18px' }}>Ingresos de Hoy</h2>
                  <span
                    style={{
                      background: 'rgba(0,242,255,0.15)',
                      color: '#00f2ff',
                      padding: '6px 14px',
                      borderRadius: '12px',
                      fontSize: '13px'
                    }}
                  >
                    23 ingresos
                  </span>
                </div>

                {/* Stats Row */}
                <div className="grid grid-cols-3 gap-3 mb-6">
                  <div
                    style={{
                      background: 'rgba(255,255,255,0.03)',
                      border: '1px solid rgba(255,255,255,0.08)',
                      borderRadius: '16px',
                      padding: '16px',
                      textAlign: 'center'
                    }}
                  >
                    <div style={{ color: '#94a3b8', fontSize: '11px', marginBottom: '4px' }}>Ingresos hoy</div>
                    <div style={{ fontSize: '22px' }}>23</div>
                  </div>
                  <div
                    style={{
                      background: 'rgba(255,255,255,0.03)',
                      border: '1px solid rgba(255,255,255,0.08)',
                      borderRadius: '16px',
                      padding: '16px',
                      textAlign: 'center'
                    }}
                  >
                    <div style={{ color: '#94a3b8', fontSize: '11px', marginBottom: '4px' }}>Denegados</div>
                    <div style={{ fontSize: '22px' }}>2</div>
                  </div>
                  <div
                    style={{
                      background: 'rgba(255,255,255,0.03)',
                      border: '1px solid rgba(255,255,255,0.08)',
                      borderRadius: '16px',
                      padding: '16px',
                      textAlign: 'center'
                    }}
                  >
                    <div style={{ color: '#94a3b8', fontSize: '11px', marginBottom: '4px' }}>Hora pico</div>
                    <div style={{ fontSize: '22px' }}>7:00 AM</div>
                  </div>
                </div>

                {/* Activity List */}
                <div
                  style={{
                    background: 'rgba(255,255,255,0.03)',
                    border: '1px solid rgba(255,255,255,0.08)',
                    borderRadius: '20px',
                    backdropFilter: 'blur(12px)',
                    padding: '20px',
                    maxHeight: '600px',
                    overflowY: 'auto'
                  }}
                >
                  {recentAccess.map((entry, index) => (
                    <div key={entry.id}>
                      <div className="flex items-center gap-3 py-3">
                        <div
                          style={{
                            width: '40px',
                            height: '40px',
                            borderRadius: '50%',
                            background: 'linear-gradient(135deg, #00f2ff 0%, #7d2ae8 100%)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '14px',
                            flexShrink: 0
                          }}
                        >
                          {entry.initials}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span style={{ fontSize: '14px' }}>{entry.name}</span>
                            <span
                              style={{
                                background: 'rgba(148,163,184,0.15)',
                                color: '#94a3b8',
                                padding: '2px 8px',
                                borderRadius: '8px',
                                fontSize: '10px'
                              }}
                            >
                              {entry.plan}
                            </span>
                          </div>
                          <div style={{ color: '#94a3b8', fontSize: '11px', marginTop: '2px' }}>
                            {entry.time}
                          </div>
                        </div>
                        <div style={{ flexShrink: 0 }}>
                          {entry.allowed ? (
                            <CheckCircle size={20} style={{ color: '#22c55e' }} />
                          ) : (
                            <XCircle size={20} style={{ color: '#ef4444' }} />
                          )}
                        </div>
                      </div>
                      {index < recentAccess.length - 1 && (
                        <div style={{ height: '1px', background: 'rgba(255,255,255,0.05)' }} />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
