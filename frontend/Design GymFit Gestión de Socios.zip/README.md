
  # Design GymFit Gestión de Socios

  This is a code bundle for Design GymFit Gestión de Socios. The original project is available at https://www.figma.com/design/rprd3zeiTKTS8xIZc4Av4g/Design-GymFit-Gesti%C3%B3n-de-Socios.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  