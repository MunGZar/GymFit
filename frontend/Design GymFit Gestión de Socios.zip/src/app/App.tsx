import { useState } from 'react';
import { Search, Plus, Eye, Pencil, Trash2, X, Users, Dumbbell, Calendar, TrendingUp, Settings, LogOut } from 'lucide-react';

export default function App() {
  const [isModalOpen, setIsModalOpen] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('Todos');
  const [planFilter, setPlanFilter] = useState('Todos');

  const members = [
    {
      id: 1,
      name: 'Carlos Andrés Rodríguez',
      email: 'carlos.rodriguez@email.com',
      cedula: '1.052.789.456',
      plan: 'Premium',
      status: 'Activa',
      expiration: '2026-05-15',
      daysRemaining: 20,
      trainer: 'María López'
    },
    {
      id: 2,
      name: 'Ana María Gómez',
      email: 'ana.gomez@email.com',
      cedula: '1.123.456.789',
      plan: 'VIP',
      status: 'Activa',
      expiration: '2026-06-30',
      daysRemaining: 66,
      trainer: 'Jorge Martínez'
    },
    {
      id: 3,
      name: 'Luis Fernando Castillo',
      email: 'luis.castillo@email.com',
      cedula: '1.098.765.432',
      plan: 'Básico',
      status: 'Vencida',
      expiration: '2026-04-10',
      daysRemaining: -15,
      trainer: null
    },
    {
      id: 4,
      name: 'Diana Carolina Torres',
      email: 'diana.torres@email.com',
      cedula: '1.234.567.890',
      plan: 'Corporativo',
      status: 'Activa',
      expiration: '2026-12-31',
      daysRemaining: 250,
      trainer: 'María López'
    },
    {
      id: 5,
      name: 'Miguel Ángel Vargas',
      email: 'miguel.vargas@email.com',
      cedula: '1.145.678.901',
      plan: 'Premium',
      status: 'Activa',
      expiration: '2026-05-28',
      daysRemaining: 33,
      trainer: 'Jorge Martínez'
    },
    {
      id: 6,
      name: 'Patricia Sánchez',
      email: 'patricia.sanchez@email.com',
      cedula: '1.187.654.321',
      plan: 'Básico',
      status: 'Cancelada',
      expiration: '2026-03-20',
      daysRemaining: -36,
      trainer: null
    }
  ];

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
  };

  const getPlanBadgeStyle = (plan: string) => {
    switch (plan) {
      case 'Básico':
        return 'bg-white/10 text-gray-400 border border-white/10';
      case 'Premium':
        return 'bg-[#00f2ff]/20 text-[#00f2ff] border border-[#00f2ff]/30';
      case 'VIP':
        return 'bg-[#7d2ae8]/20 text-[#7d2ae8] border border-[#7d2ae8]/30';
      case 'Corporativo':
        return 'bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] text-white border-0';
      default:
        return '';
    }
  };

  const getStatusBadgeStyle = (status: string) => {
    switch (status) {
      case 'Activa':
        return 'bg-green-500/20 text-green-400 border border-green-500/30 shadow-[0_0_12px_rgba(34,197,94,0.3)]';
      case 'Vencida':
        return 'bg-red-500/20 text-red-400 border border-red-500/30 shadow-[0_0_12px_rgba(239,68,68,0.3)]';
      case 'Cancelada':
        return 'bg-white/10 text-gray-400 border border-white/10';
      default:
        return '';
    }
  };

  return (
    <div className="min-h-screen bg-[#050508] text-white font-['Inter']">
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-screen w-[240px] bg-white/[0.03] border-r border-white/[0.08] backdrop-blur-[12px] p-6 flex flex-col">
        {/* Logo */}
        <div className="mb-10">
          <div className="font-['Outfit'] font-[800] text-2xl bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] bg-clip-text text-transparent">
            GymFit
          </div>
          <div className="text-xs text-[#94a3b8] mt-1">FIT-CONTROL</div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 space-y-2">
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-xl text-[#94a3b8] hover:bg-white/[0.05] transition-colors">
            <TrendingUp size={20} />
            <span className="text-sm font-medium">Dashboard</span>
          </a>
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-xl bg-gradient-to-r from-[#00f2ff]/20 to-[#7d2ae8]/20 text-white border border-white/[0.08]">
            <Users size={20} />
            <span className="text-sm font-medium">Socios</span>
          </a>
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-xl text-[#94a3b8] hover:bg-white/[0.05] transition-colors">
            <Dumbbell size={20} />
            <span className="text-sm font-medium">Entrenamientos</span>
          </a>
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-xl text-[#94a3b8] hover:bg-white/[0.05] transition-colors">
            <Calendar size={20} />
            <span className="text-sm font-medium">Calendario</span>
          </a>
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-xl text-[#94a3b8] hover:bg-white/[0.05] transition-colors">
            <Settings size={20} />
            <span className="text-sm font-medium">Configuración</span>
          </a>
        </nav>

        {/* Logout */}
        <button className="flex items-center gap-3 px-4 py-3 rounded-xl text-[#94a3b8] hover:bg-white/[0.05] transition-colors w-full mt-auto">
          <LogOut size={20} />
          <span className="text-sm font-medium">Cerrar Sesión</span>
        </button>
      </aside>

      {/* Main Content */}
      <main className="ml-[240px] p-8">
        {/* Page Header */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="font-['Outfit'] font-[800] text-[28px] text-white">Gestión de Socios</h1>
          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] rounded-xl font-medium text-white hover:opacity-90 transition-opacity"
          >
            <Plus size={20} />
            Registrar Socio
          </button>
        </div>

        {/* Filter Bar */}
        <div className="bg-white/[0.03] border border-white/[0.08] backdrop-blur-[12px] rounded-[20px] p-6 mb-6 flex gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[#94a3b8]" size={20} />
            <input
              type="text"
              placeholder="Buscar por nombre o ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white/[0.05] border border-white/[0.08] rounded-xl pl-12 pr-4 py-3 text-white placeholder:text-[#94a3b8] focus:outline-none focus:border-[#00f2ff] focus:shadow-[0_0_12px_rgba(0,242,255,0.3)] transition-all"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-white/[0.05] border border-white/[0.08] rounded-xl px-4 py-3 text-white appearance-none cursor-pointer min-w-[200px] focus:outline-none focus:border-[#00f2ff]"
          >
            <option value="Todos">Estado: Todos</option>
            <option value="Activa">Activa</option>
            <option value="Vencida">Vencida</option>
            <option value="Cancelada">Cancelada</option>
          </select>
          <select
            value={planFilter}
            onChange={(e) => setPlanFilter(e.target.value)}
            className="bg-white/[0.05] border border-white/[0.08] rounded-xl px-4 py-3 text-white appearance-none cursor-pointer min-w-[200px] focus:outline-none focus:border-[#00f2ff]"
          >
            <option value="Todos">Plan: Todos</option>
            <option value="Básico">Básico</option>
            <option value="Premium">Premium</option>
            <option value="VIP">VIP</option>
            <option value="Corporativo">Corporativo</option>
          </select>
        </div>

        {/* Members Table */}
        <div className="bg-white/[0.03] border border-white/[0.08] backdrop-blur-[12px] rounded-[20px] overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/[0.08]">
                <th className="px-6 py-4 text-left text-[11px] text-[#94a3b8] uppercase tracking-wider font-medium">#</th>
                <th className="px-6 py-4 text-left text-[11px] text-[#94a3b8] uppercase tracking-wider font-medium">Socio</th>
                <th className="px-6 py-4 text-left text-[11px] text-[#94a3b8] uppercase tracking-wider font-medium">ID / Cédula</th>
                <th className="px-6 py-4 text-left text-[11px] text-[#94a3b8] uppercase tracking-wider font-medium">Plan</th>
                <th className="px-6 py-4 text-left text-[11px] text-[#94a3b8] uppercase tracking-wider font-medium">Estado</th>
                <th className="px-6 py-4 text-left text-[11px] text-[#94a3b8] uppercase tracking-wider font-medium">Vencimiento</th>
                <th className="px-6 py-4 text-left text-[11px] text-[#94a3b8] uppercase tracking-wider font-medium">Entrenador</th>
                <th className="px-6 py-4 text-left text-[11px] text-[#94a3b8] uppercase tracking-wider font-medium">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {members.map((member, index) => (
                <tr key={member.id} className="border-b border-white/[0.08] hover:bg-white/[0.03] transition-colors">
                  <td className="px-6 py-4 text-[#94a3b8] text-sm">{index + 1}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#00f2ff] to-[#7d2ae8] flex items-center justify-center text-white text-sm font-semibold">
                        {getInitials(member.name)}
                      </div>
                      <div>
                        <div className="text-white font-medium">{member.name}</div>
                        <div className="text-[#94a3b8] text-sm">{member.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-[#94a3b8] font-mono text-sm">{member.cedula}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-block px-3 py-1 rounded-lg text-sm font-medium ${getPlanBadgeStyle(member.plan)}`}>
                      {member.plan}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-block px-3 py-1 rounded-lg text-sm font-medium ${getStatusBadgeStyle(member.status)}`}>
                      {member.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-white text-sm">{member.expiration}</div>
                    <div className="text-[#94a3b8] text-xs mt-1">
                      {member.daysRemaining > 0 ? `${member.daysRemaining} días restantes` : `Vencida hace ${Math.abs(member.daysRemaining)} días`}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={member.trainer ? 'text-white' : 'text-[#94a3b8] italic'}>
                      {member.trainer || 'Sin asignar'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button className="p-2 rounded-lg hover:bg-[#00f2ff]/20 text-[#00f2ff] transition-colors">
                        <Eye size={18} />
                      </button>
                      <button className="p-2 rounded-lg hover:bg-white/[0.05] text-[#94a3b8] transition-colors">
                        <Pencil size={18} />
                      </button>
                      <button className="p-2 rounded-lg hover:bg-red-500/20 text-[#94a3b8] hover:text-red-400 transition-colors">
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Pagination */}
          <div className="px-6 py-4 flex items-center justify-between border-t border-white/[0.08]">
            <button className="px-4 py-2 text-[#94a3b8] hover:text-white transition-colors text-sm">
              Anterior
            </button>
            <div className="flex items-center gap-2">
              <button className="w-8 h-8 rounded-lg bg-[#00f2ff] text-white text-sm font-medium">1</button>
              <button className="w-8 h-8 rounded-lg text-[#94a3b8] hover:bg-white/[0.05] transition-colors text-sm">2</button>
              <button className="w-8 h-8 rounded-lg text-[#94a3b8] hover:bg-white/[0.05] transition-colors text-sm">3</button>
            </div>
            <button className="px-4 py-2 text-[#94a3b8] hover:text-white transition-colors text-sm">
              Siguiente
            </button>
          </div>
        </div>
      </main>

      {/* Modal Overlay */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-white/[0.03] border border-white/[0.08] backdrop-blur-[20px] rounded-[20px] w-full max-w-[520px] p-6">
            {/* Modal Header */}
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-['Outfit'] font-[800] text-xl text-white">Nuevo Socio</h2>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-2 rounded-lg hover:bg-white/[0.05] text-[#94a3b8] hover:text-white transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Form */}
            <form className="space-y-4">
              <div>
                <label className="block text-[#94a3b8] text-sm mb-2">Nombre completo</label>
                <input
                  type="text"
                  className="w-full bg-white/[0.05] border border-white/[0.08] rounded-xl px-4 py-3.5 text-white placeholder:text-[#94a3b8] focus:outline-none focus:border-[#00f2ff] focus:shadow-[0_0_12px_rgba(0,242,255,0.3)] transition-all"
                  placeholder="Ingrese el nombre completo"
                />
              </div>

              <div>
                <label className="block text-[#94a3b8] text-sm mb-2">Número de identificación</label>
                <input
                  type="text"
                  className="w-full bg-white/[0.05] border border-white/[0.08] rounded-xl px-4 py-3.5 text-white placeholder:text-[#94a3b8] focus:outline-none focus:border-[#00f2ff] focus:shadow-[0_0_12px_rgba(0,242,255,0.3)] transition-all"
                  placeholder="Ej: 1.234.567.890"
                />
              </div>

              <div>
                <label className="block text-[#94a3b8] text-sm mb-2">Correo electrónico</label>
                <input
                  type="email"
                  className="w-full bg-white/[0.05] border border-white/[0.08] rounded-xl px-4 py-3.5 text-white placeholder:text-[#94a3b8] focus:outline-none focus:border-[#00f2ff] focus:shadow-[0_0_12px_rgba(0,242,255,0.3)] transition-all"
                  placeholder="correo@ejemplo.com"
                />
              </div>

              <div>
                <label className="block text-[#94a3b8] text-sm mb-2">Teléfono</label>
                <input
                  type="tel"
                  className="w-full bg-white/[0.05] border border-white/[0.08] rounded-xl px-4 py-3.5 text-white placeholder:text-[#94a3b8] focus:outline-none focus:border-[#00f2ff] focus:shadow-[0_0_12px_rgba(0,242,255,0.3)] transition-all"
                  placeholder="+57 300 123 4567"
                />
              </div>

              <div>
                <label className="block text-[#94a3b8] text-sm mb-2">Plan de membresía</label>
                <select className="w-full bg-white/[0.05] border border-white/[0.08] rounded-xl px-4 py-3.5 text-white appearance-none cursor-pointer focus:outline-none focus:border-[#00f2ff] focus:shadow-[0_0_12px_rgba(0,242,255,0.3)] transition-all">
                  <option value="">Seleccione un plan</option>
                  <option value="basico">Básico</option>
                  <option value="premium">Premium</option>
                  <option value="vip">VIP</option>
                  <option value="corporativo">Corporativo</option>
                </select>
              </div>

              <div>
                <label className="block text-[#94a3b8] text-sm mb-2">Fecha de inicio</label>
                <input
                  type="date"
                  className="w-full bg-white/[0.05] border border-white/[0.08] rounded-xl px-4 py-3.5 text-white focus:outline-none focus:border-[#00f2ff] focus:shadow-[0_0_12px_rgba(0,242,255,0.3)] transition-all"
                />
              </div>

              <div>
                <label className="block text-[#94a3b8] text-sm mb-2">Entrenador asignado</label>
                <select className="w-full bg-white/[0.05] border border-white/[0.08] rounded-xl px-4 py-3.5 text-white appearance-none cursor-pointer focus:outline-none focus:border-[#00f2ff] focus:shadow-[0_0_12px_rgba(0,242,255,0.3)] transition-all">
                  <option value="">Seleccione un entrenador</option>
                  <option value="maria">María López</option>
                  <option value="jorge">Jorge Martínez</option>
                  <option value="ninguno">Sin asignar</option>
                </select>
              </div>

              {/* Form Actions */}
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 px-6 py-3 border border-white/[0.08] rounded-xl text-[#94a3b8] hover:bg-white/[0.05] transition-colors font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 px-6 py-3 bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] rounded-xl text-white font-medium hover:opacity-90 transition-opacity"
                >
                  Registrar Socio
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
