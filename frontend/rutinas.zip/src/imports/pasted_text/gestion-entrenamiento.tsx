Design a dark-themed full-screen page for a gym management system called
"GymFit" (FIT-CONTROL). This is the "Gestión de Entrenamiento" module
used by the trainer to manage assigned members, physical evaluations,
progress tracking and workout routines.

Visual style:
- Dark background: #050508
- Primary accent: #00f2ff (cyan)
- Secondary accent: #7d2ae8 (violet/purple)
- Gradient: linear 135deg from #00f2ff to #7d2ae8
- Glassmorphism cards: background rgba(255,255,255,0.03), border 1px
  rgba(255,255,255,0.08), border-radius 20px, backdrop-filter blur 12px
- Body font: Inter (400, 500, 600)
- Heading font: Outfit (800)
- Text primary: #ffffff
- Text muted: #94a3b8

Layout:
Same fixed left sidebar (240px) with GymFit gradient logo and nav items.
"Entrenamiento" is the active nav item.

Main content area divided in two main sections:

1. PAGE HEADER
Left: title "Gestión de Entrenamiento" (Outfit 800, 28px, white).
Subtitle muted: "Administra tus socios asignados, rutinas y progreso."
Right: gradient button "+ Crear Rutina" (cyan-to-violet, 
border-radius 12px).

2. TOP STATS ROW (4 small metric cards, glassmorphism)
- Socios asignados: 14
- Rutinas creadas: 8
- Evaluaciones pendientes: 3
- Progreso promedio: 76%
Each card: gradient small icon top-left, muted label 11px uppercase,
white large number 24px Outfit 800, subtle cyan or violet glow on icon.

3. MAIN CONTENT — Two columns:

LEFT COLUMN (40% width) — Mis Socios Asignados:

Section title: "Socios asignados" (Inter 600, 16px, white).
Search input: "Buscar socio..." dark style, border-radius 12px.

Scrollable list of member cards (glassmorphism, compact):
Each card contains:
- Avatar circle with initials (gradient cyan-to-violet background)
- Member name (white, 14px, 500) + plan badge (tiny pill: 
  Premium=cyan, VIP=violet, Básico=gray)
- Muted small text: "Rutina: Fuerza Intermedia" or "Sin rutina asignada"
  (italic, muted, if no routine assigned show in amber)
- Progress bar (thin, 4px height, gradient fill, shows % of 
  monthly goal completion)
- Two icon buttons on the right: eye icon (view profile, cyan) 
  and chart icon (view progress, muted)
- Bottom of card: muted text "Última sesión: hace 2 días"

Show 6 member cards with realistic Colombian names, mix of plan 
types, different progress levels (20% to 95%), some with routines 
assigned and one without.

Active/selected member card has a cyan left border (3px) and 
slightly brighter background rgba(255,255,255,0.06).

RIGHT COLUMN (60% width) — Member Detail Panel:
Shows detail of the currently selected member from the left list.

SECTION A — Member Header:
Large avatar circle (56px, gradient background) with initials.
Name: "Carlos Andrés Ruiz" (Outfit 800, 22px, white).
Plan badge "Premium" cyan + status badge "Activa" green.
Muted text: "Socio desde: enero 2026 · ID: 1045892341"

Tab navigation below member header (4 tabs, active tab has 
gradient underline):
· Evaluación Física  · Progreso  · Rutina Asignada  · Historial

TAB 1 — Evaluación Física (shown as active):
Glassmorphism inner card titled "Evaluación Inicial — Feb 2026"
Grid of metric tiles (2x3):
- Peso: 78 kg
- Estatura: 1.75 m
- IMC: 25.5 (badge: "Normal" in green)
- % Grasa corporal: 18%
- Masa muscular: 63.9 kg
- Objetivo: "Hipertrofia" (cyan pill)
Each tile: muted label 11px, white value 20px 600 weight,
dark surface background, border-radius 12px, padding 16px.

Below the grid: a "+ Registrar Nueva Evaluación" ghost button
with cyan border and text, full width.

TAB 2 — Progreso (referenced, not expanded):
Line chart showing weight and body fat % evolution over 3 months.
Minimal chart style: cyan line for weight, violet dashed line 
for body fat. Grid lines very faint rgba white. 
X axis: months. Y axis: values. Tooltip on hover.
Below chart: comparison summary — "Perdió 2.3 kg y 3% de grasa 
desde evaluación inicial" in muted text with green up/down arrows.

TAB 3 — Rutina Asignada (referenced):
Current assigned routine card showing routine name, days per week,
list of exercises with sets x reps. Edit and reassign buttons.

TAB 4 — Historial (referenced):
Timeline of past evaluations and routine changes.

4. ROUTINES CATALOG SECTION (below the two columns, full width)
Title: "Mis Rutinas" (Inter 600, 18px, white).
Subtitle muted: "Rutinas creadas por ti, reutilizables para 
cualquier socio."
Right: "+ Crear Rutina" ghost button with cyan border.

Horizontal scrollable row of routine cards (glassmorphism):

Each routine card (approx 220px wide):
- Top gradient colored bar (thin, 4px)
- Routine name: "Fuerza Intermedia" (Inter 600, 16px, white)
- Tags row: "3 días/sem" · "Intermedio" · "Hipertrofia" 
  (tiny gray pills)
- Exercise count: "8 ejercicios" (muted small text)
- Assigned to: "4 socios" (muted small text with person icon)
- Bottom: two icon buttons — assign (person+ icon, cyan) 
  and edit (pencil, muted)

Show 4 routine cards:
· Fuerza Intermedia — 8 ejercicios — 4 socios
· Cardio y Resistencia — 6 ejercicios — 2 socios  
· Rehabilitación Básica — 5 ejercicios — 1 socio
· Definición Avanzada — 10 ejercicios — 3 socios

5. MODAL — "Crear Rutina" (show as open overlay)
Centered modal (max-width 560px), glassmorphism, blur 20px.
Title: "Nueva Rutina de Ejercicio" (Outfit 800, 20px, white).

Form sections:
SECTION A — Info general:
- Nombre de la rutina (text input)
- Nivel (select: Principiante / Intermedio / Avanzado)
- Objetivo (select: Pérdida de peso / Hipertrofia / Resistencia /
  Rehabilitación)
- Días por semana (number input, 1-7)

SECTION B — Ejercicios (dynamic list):
Label: "Ejercicios" (muted 13px)
Each exercise row (add/remove dynamically):
- Nombre del ejercicio (text input, wider)
- Series (small number input)
- Repeticiones (small number input)
- Descanso en seg (small number input)
- Remove icon button (red X, right side)
Below the exercise list: "+ Agregar ejercicio" ghost link in cyan.

SECTION C — Observaciones:
Textarea: "Notas técnicas o recomendaciones..." (3 rows, dark style)

Bottom buttons: "Cancelar" (ghost muted) and "Guardar Rutina" 
(gradient cyan-to-violet, font-weight 700).
Dark overlay behind modal: rgba(0,0,0,0.6).