import { Search, Eye, BarChart3 } from 'lucide-react';

interface Member {
  id: string;
  name: string;
  plan: 'Premium' | 'VIP' | 'Básico';
  routine: string | null;
  progress: number;
  lastSession: string;
}

const members: Member[] = [
  { id: '1', name: 'Carlos Andrés Ruiz', plan: 'Premium', routine: 'Fuerza Intermedia', progress: 85, lastSession: 'hace 2 días' },
  { id: '2', name: 'María Camila López', plan: 'VIP', routine: 'Cardio y Resistencia', progress: 92, lastSession: 'hace 1 día' },
  { id: '3', name: 'Juan Pablo Hernández', plan: 'Básico', routine: null, progress: 20, lastSession: 'hace 5 días' },
  { id: '4', name: 'Laura Valentina Gómez', plan: 'Premium', routine: 'Definición Avanzada', progress: 78, lastSession: 'hace 1 día' },
  { id: '5', name: 'Andrés Felipe Martínez', plan: 'VIP', routine: 'Fuerza Intermedia', progress: 95, lastSession: 'hoy' },
  { id: '6', name: 'Carolina Ramírez', plan: 'Premium', routine: 'Rehabilitación Básica', progress: 65, lastSession: 'hace 3 días' },
];

interface MemberListProps {
  selectedMemberId: string;
  onSelectMember: (id: string) => void;
}

export function MemberList({ selectedMemberId, onSelectMember }: MemberListProps) {
  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).slice(0, 2).join('');
  };

  const getPlanColor = (plan: string) => {
    switch (plan) {
      case 'Premium': return '#00f2ff';
      case 'VIP': return '#7d2ae8';
      default: return '#6b7280';
    }
  };

  return (
    <div className="rounded-[20px] p-6 h-[600px] flex flex-col" style={{
      background: 'rgba(255, 255, 255, 0.03)',
      border: '1px solid rgba(255, 255, 255, 0.08)',
      backdropFilter: 'blur(12px)'
    }}>
      <div style={{ fontSize: '16px', fontWeight: 600, color: '#ffffff', marginBottom: '16px' }}>
        Socios asignados
      </div>

      <div className="relative mb-4">
        <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#94a3b8' }} />
        <input
          type="text"
          placeholder="Buscar socio..."
          className="w-full pl-10 pr-4 py-3 rounded-xl outline-none"
          style={{
            background: 'rgba(0, 0, 0, 0.3)',
            border: '1px solid rgba(255, 255, 255, 0.08)',
            color: '#ffffff',
            fontSize: '14px'
          }}
        />
      </div>

      <div className="flex-1 overflow-y-auto space-y-3" style={{
        scrollbarWidth: 'thin',
        scrollbarColor: 'rgba(255, 255, 255, 0.2) transparent'
      }}>
        {members.map((member) => (
          <div
            key={member.id}
            onClick={() => onSelectMember(member.id)}
            className="p-4 rounded-xl cursor-pointer transition-all relative"
            style={{
              background: selectedMemberId === member.id ? 'rgba(255, 255, 255, 0.06)' : 'rgba(255, 255, 255, 0.02)',
              border: '1px solid rgba(255, 255, 255, 0.05)',
              borderLeft: selectedMemberId === member.id ? '3px solid #00f2ff' : '3px solid transparent'
            }}
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{
                background: 'linear-gradient(135deg, #00f2ff, #7d2ae8)',
                fontSize: '14px',
                fontWeight: 600
              }}>
                {getInitials(member.name)}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span style={{ fontSize: '14px', fontWeight: 500, color: '#ffffff' }}>
                    {member.name}
                  </span>
                  <span className="px-2 py-0.5 rounded-full" style={{
                    background: `${getPlanColor(member.plan)}20`,
                    color: getPlanColor(member.plan),
                    fontSize: '10px',
                    fontWeight: 600
                  }}>
                    {member.plan}
                  </span>
                </div>

                <div style={{
                  fontSize: '12px',
                  color: member.routine ? '#94a3b8' : '#fbbf24',
                  fontStyle: member.routine ? 'normal' : 'italic',
                  marginBottom: '8px'
                }}>
                  {member.routine ? `Rutina: ${member.routine}` : 'Sin rutina asignada'}
                </div>

                <div className="w-full h-1 rounded-full mb-2" style={{ background: 'rgba(255, 255, 255, 0.1)' }}>
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${member.progress}%`,
                      background: 'linear-gradient(90deg, #00f2ff, #7d2ae8)'
                    }}
                  />
                </div>

                <div style={{ fontSize: '11px', color: '#94a3b8' }}>
                  Última sesión: {member.lastSession}
                </div>
              </div>

              <div className="flex gap-1 flex-shrink-0">
                <button className="p-2 rounded-lg hover:bg-white/5 transition-colors">
                  <Eye size={16} style={{ color: '#00f2ff' }} />
                </button>
                <button className="p-2 rounded-lg hover:bg-white/5 transition-colors">
                  <BarChart3 size={16} style={{ color: '#94a3b8' }} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
