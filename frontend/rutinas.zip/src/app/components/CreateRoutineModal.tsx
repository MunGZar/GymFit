import { useState } from 'react';
import { X } from 'lucide-react';

interface Exercise {
  id: string;
  name: string;
  sets: string;
  reps: string;
  rest: string;
}

interface CreateRoutineModalProps {
  onClose: () => void;
}

export function CreateRoutineModal({ onClose }: CreateRoutineModalProps) {
  const [exercises, setExercises] = useState<Exercise[]>([
    { id: '1', name: '', sets: '', reps: '', rest: '' }
  ]);

  const addExercise = () => {
    setExercises([
      ...exercises,
      { id: Date.now().toString(), name: '', sets: '', reps: '', rest: '' }
    ]);
  };

  const removeExercise = (id: string) => {
    if (exercises.length > 1) {
      setExercises(exercises.filter(ex => ex.id !== id));
    }
  };

  const updateExercise = (id: string, field: keyof Exercise, value: string) => {
    setExercises(exercises.map(ex =>
      ex.id === id ? { ...ex, [field]: value } : ex
    ));
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50" style={{
      background: 'rgba(0, 0, 0, 0.6)',
      backdropFilter: 'blur(4px)'
    }}>
      <div className="w-full max-w-[560px] max-h-[90vh] overflow-y-auto rounded-[20px] p-6" style={{
        background: 'rgba(10, 10, 15, 0.95)',
        border: '1px solid rgba(255, 255, 255, 0.1)',
        backdropFilter: 'blur(20px)',
        scrollbarWidth: 'thin',
        scrollbarColor: 'rgba(255, 255, 255, 0.2) transparent'
      }}>
        {/* Header */}
        <div className="flex justify-between items-start mb-6">
          <div style={{ fontFamily: 'Outfit, sans-serif', fontSize: '20px', fontWeight: 800, color: '#ffffff' }}>
            Nueva Rutina de Ejercicio
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-white/5 transition-colors"
            style={{ color: '#94a3b8' }}
          >
            <X size={20} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={(e) => e.preventDefault()}>
          {/* Section A - Info General */}
          <div className="mb-6">
            <div style={{ fontSize: '13px', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '16px' }}>
              Información general
            </div>

            <div className="space-y-4">
              <div>
                <label className="block mb-2" style={{ fontSize: '13px', color: '#94a3b8' }}>
                  Nombre de la rutina
                </label>
                <input
                  type="text"
                  placeholder="Ej: Fuerza Intermedia"
                  className="w-full px-4 py-3 rounded-xl outline-none"
                  style={{
                    background: 'rgba(0, 0, 0, 0.3)',
                    border: '1px solid rgba(255, 255, 255, 0.08)',
                    color: '#ffffff',
                    fontSize: '14px'
                  }}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block mb-2" style={{ fontSize: '13px', color: '#94a3b8' }}>
                    Nivel
                  </label>
                  <select
                    className="w-full px-4 py-3 rounded-xl outline-none"
                    style={{
                      background: 'rgba(0, 0, 0, 0.3)',
                      border: '1px solid rgba(255, 255, 255, 0.08)',
                      color: '#ffffff',
                      fontSize: '14px'
                    }}
                  >
                    <option value="">Seleccionar</option>
                    <option value="principiante">Principiante</option>
                    <option value="intermedio">Intermedio</option>
                    <option value="avanzado">Avanzado</option>
                  </select>
                </div>

                <div>
                  <label className="block mb-2" style={{ fontSize: '13px', color: '#94a3b8' }}>
                    Días por semana
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="7"
                    placeholder="3"
                    className="w-full px-4 py-3 rounded-xl outline-none"
                    style={{
                      background: 'rgba(0, 0, 0, 0.3)',
                      border: '1px solid rgba(255, 255, 255, 0.08)',
                      color: '#ffffff',
                      fontSize: '14px'
                    }}
                  />
                </div>
              </div>

              <div>
                <label className="block mb-2" style={{ fontSize: '13px', color: '#94a3b8' }}>
                  Objetivo
                </label>
                <select
                  className="w-full px-4 py-3 rounded-xl outline-none"
                  style={{
                    background: 'rgba(0, 0, 0, 0.3)',
                    border: '1px solid rgba(255, 255, 255, 0.08)',
                    color: '#ffffff',
                    fontSize: '14px'
                  }}
                >
                  <option value="">Seleccionar</option>
                  <option value="perdida">Pérdida de peso</option>
                  <option value="hipertrofia">Hipertrofia</option>
                  <option value="resistencia">Resistencia</option>
                  <option value="rehabilitacion">Rehabilitación</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section B - Ejercicios */}
          <div className="mb-6">
            <div style={{ fontSize: '13px', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '16px' }}>
              Ejercicios
            </div>

            <div className="space-y-3">
              {exercises.map((exercise, index) => (
                <div
                  key={exercise.id}
                  className="p-4 rounded-xl"
                  style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    border: '1px solid rgba(255, 255, 255, 0.05)'
                  }}
                >
                  <div className="flex items-start gap-3">
                    <div className="flex-1 space-y-3">
                      <input
                        type="text"
                        placeholder="Nombre del ejercicio"
                        value={exercise.name}
                        onChange={(e) => updateExercise(exercise.id, 'name', e.target.value)}
                        className="w-full px-3 py-2 rounded-lg outline-none"
                        style={{
                          background: 'rgba(0, 0, 0, 0.3)',
                          border: '1px solid rgba(255, 255, 255, 0.08)',
                          color: '#ffffff',
                          fontSize: '13px'
                        }}
                      />

                      <div className="grid grid-cols-3 gap-2">
                        <input
                          type="number"
                          placeholder="Series"
                          value={exercise.sets}
                          onChange={(e) => updateExercise(exercise.id, 'sets', e.target.value)}
                          className="px-3 py-2 rounded-lg outline-none"
                          style={{
                            background: 'rgba(0, 0, 0, 0.3)',
                            border: '1px solid rgba(255, 255, 255, 0.08)',
                            color: '#ffffff',
                            fontSize: '13px'
                          }}
                        />
                        <input
                          type="number"
                          placeholder="Reps"
                          value={exercise.reps}
                          onChange={(e) => updateExercise(exercise.id, 'reps', e.target.value)}
                          className="px-3 py-2 rounded-lg outline-none"
                          style={{
                            background: 'rgba(0, 0, 0, 0.3)',
                            border: '1px solid rgba(255, 255, 255, 0.08)',
                            color: '#ffffff',
                            fontSize: '13px'
                          }}
                        />
                        <input
                          type="number"
                          placeholder="Desc (s)"
                          value={exercise.rest}
                          onChange={(e) => updateExercise(exercise.id, 'rest', e.target.value)}
                          className="px-3 py-2 rounded-lg outline-none"
                          style={{
                            background: 'rgba(0, 0, 0, 0.3)',
                            border: '1px solid rgba(255, 255, 255, 0.08)',
                            color: '#ffffff',
                            fontSize: '13px'
                          }}
                        />
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => removeExercise(exercise.id)}
                      className="p-2 rounded-lg hover:bg-red-500/10 transition-colors"
                      style={{ color: '#ef4444' }}
                    >
                      <X size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <button
              type="button"
              onClick={addExercise}
              className="mt-3 text-left transition-colors"
              style={{ color: '#00f2ff', fontSize: '13px', fontWeight: 600 }}
            >
              + Agregar ejercicio
            </button>
          </div>

          {/* Section C - Observaciones */}
          <div className="mb-6">
            <div style={{ fontSize: '13px', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '16px' }}>
              Observaciones
            </div>

            <textarea
              placeholder="Notas técnicas o recomendaciones..."
              rows={3}
              className="w-full px-4 py-3 rounded-xl outline-none resize-none"
              style={{
                background: 'rgba(0, 0, 0, 0.3)',
                border: '1px solid rgba(255, 255, 255, 0.08)',
                color: '#ffffff',
                fontSize: '14px'
              }}
            />
          </div>

          {/* Bottom Buttons */}
          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 rounded-xl transition-all"
              style={{
                background: 'transparent',
                border: '1px solid rgba(255, 255, 255, 0.1)',
                color: '#94a3b8',
                fontSize: '14px',
                fontWeight: 600
              }}
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 py-3 rounded-xl transition-all"
              style={{
                background: 'linear-gradient(135deg, #00f2ff, #7d2ae8)',
                color: '#ffffff',
                fontSize: '14px',
                fontWeight: 700,
                border: 'none'
              }}
            >
              Guardar Rutina
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
