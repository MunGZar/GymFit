import { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface MemberDetailProps {
  memberId: string;
}

const chartData = [
  { month: 'Ene', weight: 80.3, fat: 21 },
  { month: 'Feb', weight: 79.1, fat: 19.5 },
  { month: 'Mar', weight: 78.5, fat: 18.8 },
  { month: 'Abr', weight: 78.0, fat: 18.0 },
];

export function MemberDetail({ memberId }: MemberDetailProps) {
  const [activeTab, setActiveTab] = useState('evaluation');

  const tabs = [
    { id: 'evaluation', label: 'Evaluación Física' },
    { id: 'progress', label: 'Progreso' },
    { id: 'routine', label: 'Rutina Asignada' },
    { id: 'history', label: 'Historial' },
  ];

  return (
    <div className="rounded-[20px] p-6 h-[600px] flex flex-col" style={{
      background: 'rgba(255, 255, 255, 0.03)',
      border: '1px solid rgba(255, 255, 255, 0.08)',
      backdropFilter: 'blur(12px)'
    }}>
      {/* Member Header */}
      <div className="flex items-start gap-4 pb-5 border-b border-white/5 mb-5">
        <div className="w-14 h-14 rounded-full flex items-center justify-center flex-shrink-0" style={{
          background: 'linear-gradient(135deg, #00f2ff, #7d2ae8)',
          fontSize: '18px',
          fontWeight: 600
        }}>
          CR
        </div>

        <div className="flex-1">
          <div style={{ fontFamily: 'Outfit, sans-serif', fontSize: '22px', fontWeight: 800, color: '#ffffff', marginBottom: '8px' }}>
            Carlos Andrés Ruiz
          </div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-3 py-1 rounded-full" style={{
              background: 'rgba(0, 242, 255, 0.15)',
              color: '#00f2ff',
              fontSize: '11px',
              fontWeight: 600
            }}>
              Premium
            </span>
            <span className="px-3 py-1 rounded-full" style={{
              background: 'rgba(34, 197, 94, 0.15)',
              color: '#22c55e',
              fontSize: '11px',
              fontWeight: 600
            }}>
              Activa
            </span>
          </div>
          <div style={{ fontSize: '12px', color: '#94a3b8' }}>
            Socio desde: enero 2026 · ID: 1045892341
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-6 border-b border-white/5 mb-5">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className="pb-3 relative transition-colors"
            style={{
              color: activeTab === tab.id ? '#ffffff' : '#94a3b8',
              fontSize: '14px',
              fontWeight: activeTab === tab.id ? 600 : 500
            }}
          >
            {tab.label}
            {activeTab === tab.id && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5" style={{
                background: 'linear-gradient(90deg, #00f2ff, #7d2ae8)'
              }} />
            )}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto" style={{
        scrollbarWidth: 'thin',
        scrollbarColor: 'rgba(255, 255, 255, 0.2) transparent'
      }}>
        {activeTab === 'evaluation' && (
          <div>
            <div className="p-5 rounded-xl mb-4" style={{
              background: 'rgba(255, 255, 255, 0.02)',
              border: '1px solid rgba(255, 255, 255, 0.05)'
            }}>
              <div style={{ fontSize: '14px', fontWeight: 600, color: '#ffffff', marginBottom: '16px' }}>
                Evaluación Inicial — Feb 2026
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 rounded-xl" style={{ background: 'rgba(0, 0, 0, 0.3)' }}>
                  <div style={{ fontSize: '11px', color: '#94a3b8', marginBottom: '6px' }}>
                    Peso
                  </div>
                  <div style={{ fontSize: '20px', fontWeight: 600, color: '#ffffff' }}>
                    78 kg
                  </div>
                </div>

                <div className="p-4 rounded-xl" style={{ background: 'rgba(0, 0, 0, 0.3)' }}>
                  <div style={{ fontSize: '11px', color: '#94a3b8', marginBottom: '6px' }}>
                    Estatura
                  </div>
                  <div style={{ fontSize: '20px', fontWeight: 600, color: '#ffffff' }}>
                    1.75 m
                  </div>
                </div>

                <div className="p-4 rounded-xl" style={{ background: 'rgba(0, 0, 0, 0.3)' }}>
                  <div style={{ fontSize: '11px', color: '#94a3b8', marginBottom: '6px' }}>
                    IMC
                  </div>
                  <div className="flex items-center gap-2">
                    <span style={{ fontSize: '20px', fontWeight: 600, color: '#ffffff' }}>
                      25.5
                    </span>
                    <span className="px-2 py-0.5 rounded-full" style={{
                      background: 'rgba(34, 197, 94, 0.15)',
                      color: '#22c55e',
                      fontSize: '10px',
                      fontWeight: 600
                    }}>
                      Normal
                    </span>
                  </div>
                </div>

                <div className="p-4 rounded-xl" style={{ background: 'rgba(0, 0, 0, 0.3)' }}>
                  <div style={{ fontSize: '11px', color: '#94a3b8', marginBottom: '6px' }}>
                    % Grasa corporal
                  </div>
                  <div style={{ fontSize: '20px', fontWeight: 600, color: '#ffffff' }}>
                    18%
                  </div>
                </div>

                <div className="p-4 rounded-xl" style={{ background: 'rgba(0, 0, 0, 0.3)' }}>
                  <div style={{ fontSize: '11px', color: '#94a3b8', marginBottom: '6px' }}>
                    Masa muscular
                  </div>
                  <div style={{ fontSize: '20px', fontWeight: 600, color: '#ffffff' }}>
                    63.9 kg
                  </div>
                </div>

                <div className="p-4 rounded-xl" style={{ background: 'rgba(0, 0, 0, 0.3)' }}>
                  <div style={{ fontSize: '11px', color: '#94a3b8', marginBottom: '6px' }}>
                    Objetivo
                  </div>
                  <div>
                    <span className="px-3 py-1 rounded-full inline-block" style={{
                      background: 'rgba(0, 242, 255, 0.15)',
                      color: '#00f2ff',
                      fontSize: '12px',
                      fontWeight: 600
                    }}>
                      Hipertrofia
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <button className="w-full py-3 rounded-xl transition-all" style={{
              background: 'transparent',
              border: '2px solid #00f2ff',
              color: '#00f2ff',
              fontSize: '14px',
              fontWeight: 600
            }}>
              + Registrar Nueva Evaluación
            </button>
          </div>
        )}

        {activeTab === 'progress' && (
          <div>
            <div className="p-5 rounded-xl mb-4" style={{
              background: 'rgba(255, 255, 255, 0.02)',
              border: '1px solid rgba(255, 255, 255, 0.05)'
            }}>
              <div style={{ fontSize: '14px', fontWeight: 600, color: '#ffffff', marginBottom: '20px' }}>
                Evolución de peso y grasa corporal
              </div>

              <div style={{ height: '250px' }}>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.05)" />
                    <XAxis
                      dataKey="month"
                      stroke="#94a3b8"
                      style={{ fontSize: '12px' }}
                    />
                    <YAxis
                      stroke="#94a3b8"
                      style={{ fontSize: '12px' }}
                    />
                    <Tooltip
                      contentStyle={{
                        background: 'rgba(10, 10, 15, 0.95)',
                        border: '1px solid rgba(255, 255, 255, 0.1)',
                        borderRadius: '8px',
                        color: '#ffffff'
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="weight"
                      stroke="#00f2ff"
                      strokeWidth={2}
                      name="Peso (kg)"
                    />
                    <Line
                      type="monotone"
                      dataKey="fat"
                      stroke="#7d2ae8"
                      strokeWidth={2}
                      strokeDasharray="5 5"
                      name="Grasa (%)"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="p-4 rounded-xl" style={{
              background: 'rgba(255, 255, 255, 0.02)',
              border: '1px solid rgba(255, 255, 255, 0.05)'
            }}>
              <div style={{ fontSize: '13px', color: '#94a3b8' }}>
                Perdió <span style={{ color: '#22c55e', fontWeight: 600 }}>2.3 kg</span> y <span style={{ color: '#22c55e', fontWeight: 600 }}>3%</span> de grasa desde evaluación inicial
              </div>
            </div>
          </div>
        )}

        {activeTab === 'routine' && (
          <div className="p-5 rounded-xl" style={{
            background: 'rgba(255, 255, 255, 0.02)',
            border: '1px solid rgba(255, 255, 255, 0.05)'
          }}>
            <div style={{ fontSize: '14px', fontWeight: 600, color: '#ffffff', marginBottom: '12px' }}>
              Fuerza Intermedia
            </div>
            <div style={{ fontSize: '12px', color: '#94a3b8' }}>
              Rutina actualmente asignada a este socio
            </div>
          </div>
        )}

        {activeTab === 'history' && (
          <div className="p-5 rounded-xl" style={{
            background: 'rgba(255, 255, 255, 0.02)',
            border: '1px solid rgba(255, 255, 255, 0.05)'
          }}>
            <div style={{ fontSize: '14px', fontWeight: 600, color: '#ffffff', marginBottom: '12px' }}>
              Historial de evaluaciones
            </div>
            <div style={{ fontSize: '12px', color: '#94a3b8' }}>
              Timeline de evaluaciones previas y cambios de rutina
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
