import { UserPlus, Pencil } from 'lucide-react';

interface Routine {
  id: string;
  name: string;
  tags: string[];
  exercises: number;
  assignedTo: number;
  color: string;
}

const routines: Routine[] = [
  {
    id: '1',
    name: 'Fuerza Intermedia',
    tags: ['3 días/sem', 'Intermedio', 'Hipertrofia'],
    exercises: 8,
    assignedTo: 4,
    color: '#00f2ff'
  },
  {
    id: '2',
    name: 'Cardio y Resistencia',
    tags: ['4 días/sem', 'Principiante', 'Resistencia'],
    exercises: 6,
    assignedTo: 2,
    color: '#7d2ae8'
  },
  {
    id: '3',
    name: 'Rehabilitación Básica',
    tags: ['2 días/sem', 'Principiante', 'Rehabilitación'],
    exercises: 5,
    assignedTo: 1,
    color: '#22c55e'
  },
  {
    id: '4',
    name: 'Definición Avanzada',
    tags: ['5 días/sem', 'Avanzado', 'Pérdida de peso'],
    exercises: 10,
    assignedTo: 3,
    color: '#f97316'
  }
];

interface RoutinesCatalogProps {
  onCreateRoutine: () => void;
}

export function RoutinesCatalog({ onCreateRoutine }: RoutinesCatalogProps) {
  return (
    <div>
      <div className="flex justify-between items-center mb-5">
        <div>
          <div style={{ fontSize: '18px', fontWeight: 600, color: '#ffffff', marginBottom: '4px' }}>
            Mis Rutinas
          </div>
          <div style={{ fontSize: '13px', color: '#94a3b8' }}>
            Rutinas creadas por ti, reutilizables para cualquier socio.
          </div>
        </div>
        <button
          onClick={onCreateRoutine}
          className="px-4 py-2 rounded-xl transition-all"
          style={{
            background: 'transparent',
            border: '2px solid #00f2ff',
            color: '#00f2ff',
            fontSize: '13px',
            fontWeight: 600
          }}
        >
          + Crear Rutina
        </button>
      </div>

      <div className="flex gap-4 overflow-x-auto pb-4" style={{
        scrollbarWidth: 'thin',
        scrollbarColor: 'rgba(255, 255, 255, 0.2) transparent'
      }}>
        {routines.map((routine) => (
          <div
            key={routine.id}
            className="flex-shrink-0 p-5 rounded-xl relative overflow-hidden"
            style={{
              width: '220px',
              background: 'rgba(255, 255, 255, 0.03)',
              border: '1px solid rgba(255, 255, 255, 0.08)',
              backdropFilter: 'blur(12px)'
            }}
          >
            <div className="absolute top-0 left-0 right-0 h-1" style={{
              background: `linear-gradient(90deg, ${routine.color}, ${routine.color}80)`
            }} />

            <div style={{ fontSize: '16px', fontWeight: 600, color: '#ffffff', marginBottom: '10px', marginTop: '8px' }}>
              {routine.name}
            </div>

            <div className="flex flex-wrap gap-1 mb-3">
              {routine.tags.map((tag, index) => (
                <span
                  key={index}
                  className="px-2 py-1 rounded-full"
                  style={{
                    background: 'rgba(107, 114, 128, 0.2)',
                    color: '#9ca3af',
                    fontSize: '10px',
                    fontWeight: 500
                  }}
                >
                  {tag}
                </span>
              ))}
            </div>

            <div style={{ fontSize: '12px', color: '#94a3b8', marginBottom: '6px' }}>
              {routine.exercises} ejercicios
            </div>

            <div className="flex items-center gap-1 mb-4" style={{ fontSize: '12px', color: '#94a3b8' }}>
              <UserPlus size={14} />
              <span>{routine.assignedTo} socios</span>
            </div>

            <div className="flex gap-2 pt-3 border-t border-white/5">
              <button className="flex-1 flex items-center justify-center gap-2 py-2 rounded-lg transition-all hover:bg-cyan-500/10" style={{
                color: '#00f2ff',
                fontSize: '12px',
                fontWeight: 600
              }}>
                <UserPlus size={14} />
                Asignar
              </button>
              <button className="flex-1 flex items-center justify-center gap-2 py-2 rounded-lg transition-all hover:bg-white/5" style={{
                color: '#94a3b8',
                fontSize: '12px',
                fontWeight: 600
              }}>
                <Pencil size={14} />
                Editar
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
