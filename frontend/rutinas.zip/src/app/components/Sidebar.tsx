import { Home, Dumbbell, Users, Calendar, BarChart3, Settings } from 'lucide-react';

export function Sidebar() {
  const navItems = [
    { icon: Home, label: 'Dashboard', active: false },
    { icon: Dumbbell, label: 'Entrenamiento', active: true },
    { icon: Users, label: 'Socios', active: false },
    { icon: Calendar, label: 'Horarios', active: false },
    { icon: BarChart3, label: 'Reportes', active: false },
    { icon: Settings, label: 'Configuración', active: false },
  ];

  return (
    <aside className="fixed left-0 top-0 h-screen bg-[#0a0a0f] border-r border-white/5 flex flex-col" style={{ width: '240px' }}>
      <div className="p-6 border-b border-white/5">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{
            background: 'linear-gradient(135deg, #00f2ff, #7d2ae8)'
          }}>
            <Dumbbell size={24} className="text-white" />
          </div>
          <div>
            <div style={{ fontFamily: 'Outfit, sans-serif', fontSize: '18px', fontWeight: 800 }}>
              GymFit
            </div>
            <div style={{ fontSize: '10px', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '1px' }}>
              FIT-CONTROL
            </div>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4">
        {navItems.map((item) => (
          <button
            key={item.label}
            className="w-full flex items-center gap-3 px-4 py-3 mb-1 rounded-xl transition-all"
            style={{
              background: item.active ? 'linear-gradient(135deg, rgba(0, 242, 255, 0.1), rgba(125, 42, 232, 0.1))' : 'transparent',
              color: item.active ? '#00f2ff' : '#94a3b8',
              borderLeft: item.active ? '3px solid #00f2ff' : '3px solid transparent'
            }}
          >
            <item.icon size={20} />
            <span style={{ fontSize: '14px', fontWeight: item.active ? 600 : 500 }}>
              {item.label}
            </span>
          </button>
        ))}
      </nav>
    </aside>
  );
}
