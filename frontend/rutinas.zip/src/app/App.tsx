import { useState } from 'react';
import { Eye, TrendingUp, User, Pencil, UserPlus, X, Search, Activity, Users, Calendar, BarChart3, Dumbbell } from 'lucide-react';
import { MemberList } from './components/MemberList';
import { MemberDetail } from './components/MemberDetail';
import { RoutinesCatalog } from './components/RoutinesCatalog';
import { CreateRoutineModal } from './components/CreateRoutineModal';
import { Sidebar } from './components/Sidebar';

export default function App() {
  const [selectedMemberId, setSelectedMemberId] = useState('1');
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div className="min-h-screen flex" style={{
      backgroundColor: '#050508',
      fontFamily: 'Inter, sans-serif',
      color: '#ffffff'
    }}>
      <Sidebar />

      <main className="flex-1 ml-[240px] p-8">
        <div className="max-w-[1400px] mx-auto">
          {/* Page Header */}
          <div className="flex justify-between items-start mb-8">
            <div>
              <h1 style={{
                fontFamily: 'Outfit, sans-serif',
                fontSize: '28px',
                fontWeight: 800,
                color: '#ffffff',
                marginBottom: '8px'
              }}>
                Gestión de Entrenamiento
              </h1>
              <p style={{
                color: '#94a3b8',
                fontSize: '14px'
              }}>
                Administra tus socios asignados, rutinas y progreso.
              </p>
            </div>
            <button
              onClick={() => setIsModalOpen(true)}
              className="px-6 py-3 rounded-xl text-white font-semibold transition-all"
              style={{
                background: 'linear-gradient(135deg, #00f2ff, #7d2ae8)',
                fontSize: '14px'
              }}
            >
              + Crear Rutina
            </button>
          </div>

          {/* Top Stats Row */}
          <div className="grid grid-cols-4 gap-4 mb-8">
            <div className="p-5 rounded-[20px] relative overflow-hidden" style={{
              background: 'rgba(255, 255, 255, 0.03)',
              border: '1px solid rgba(255, 255, 255, 0.08)',
              backdropFilter: 'blur(12px)'
            }}>
              <div className="flex items-center justify-center w-10 h-10 rounded-xl mb-3" style={{
                background: 'linear-gradient(135deg, rgba(0, 242, 255, 0.15), rgba(125, 42, 232, 0.15))',
                boxShadow: '0 0 20px rgba(0, 242, 255, 0.3)'
              }}>
                <Users size={20} style={{ color: '#00f2ff' }} />
              </div>
              <div style={{ fontSize: '11px', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '4px' }}>
                Socios asignados
              </div>
              <div style={{ fontFamily: 'Outfit, sans-serif', fontSize: '24px', fontWeight: 800, color: '#ffffff' }}>
                14
              </div>
            </div>

            <div className="p-5 rounded-[20px] relative overflow-hidden" style={{
              background: 'rgba(255, 255, 255, 0.03)',
              border: '1px solid rgba(255, 255, 255, 0.08)',
              backdropFilter: 'blur(12px)'
            }}>
              <div className="flex items-center justify-center w-10 h-10 rounded-xl mb-3" style={{
                background: 'linear-gradient(135deg, rgba(125, 42, 232, 0.15), rgba(0, 242, 255, 0.15))',
                boxShadow: '0 0 20px rgba(125, 42, 232, 0.3)'
              }}>
                <Dumbbell size={20} style={{ color: '#7d2ae8' }} />
              </div>
              <div style={{ fontSize: '11px', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '4px' }}>
                Rutinas creadas
              </div>
              <div style={{ fontFamily: 'Outfit, sans-serif', fontSize: '24px', fontWeight: 800, color: '#ffffff' }}>
                8
              </div>
            </div>

            <div className="p-5 rounded-[20px] relative overflow-hidden" style={{
              background: 'rgba(255, 255, 255, 0.03)',
              border: '1px solid rgba(255, 255, 255, 0.08)',
              backdropFilter: 'blur(12px)'
            }}>
              <div className="flex items-center justify-center w-10 h-10 rounded-xl mb-3" style={{
                background: 'linear-gradient(135deg, rgba(0, 242, 255, 0.15), rgba(125, 42, 232, 0.15))',
                boxShadow: '0 0 20px rgba(0, 242, 255, 0.3)'
              }}>
                <Activity size={20} style={{ color: '#00f2ff' }} />
              </div>
              <div style={{ fontSize: '11px', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '4px' }}>
                Evaluaciones pendientes
              </div>
              <div style={{ fontFamily: 'Outfit, sans-serif', fontSize: '24px', fontWeight: 800, color: '#ffffff' }}>
                3
              </div>
            </div>

            <div className="p-5 rounded-[20px] relative overflow-hidden" style={{
              background: 'rgba(255, 255, 255, 0.03)',
              border: '1px solid rgba(255, 255, 255, 0.08)',
              backdropFilter: 'blur(12px)'
            }}>
              <div className="flex items-center justify-center w-10 h-10 rounded-xl mb-3" style={{
                background: 'linear-gradient(135deg, rgba(125, 42, 232, 0.15), rgba(0, 242, 255, 0.15))',
                boxShadow: '0 0 20px rgba(125, 42, 232, 0.3)'
              }}>
                <TrendingUp size={20} style={{ color: '#7d2ae8' }} />
              </div>
              <div style={{ fontSize: '11px', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '4px' }}>
                Progreso promedio
              </div>
              <div style={{ fontFamily: 'Outfit, sans-serif', fontSize: '24px', fontWeight: 800, color: '#ffffff' }}>
                76%
              </div>
            </div>
          </div>

          {/* Main Content - Two Columns */}
          <div className="grid grid-cols-[40%_60%] gap-6 mb-8">
            <MemberList
              selectedMemberId={selectedMemberId}
              onSelectMember={setSelectedMemberId}
            />
            <MemberDetail memberId={selectedMemberId} />
          </div>

          {/* Routines Catalog */}
          <RoutinesCatalog onCreateRoutine={() => setIsModalOpen(true)} />
        </div>
      </main>

      {/* Modal */}
      {isModalOpen && <CreateRoutineModal onClose={() => setIsModalOpen(false)} />}
    </div>
  );
}
