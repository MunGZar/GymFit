
  # rutinas

  This is a code bundle for rutinas. The original project is available at https://www.figma.com/design/4Uwob1Hv19ZH042y5qRdDD/rutinas.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  