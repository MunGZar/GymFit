import {
  LayoutDashboard,
  Users,
  CreditCard,
  UserCog,
  Dumbbell,
  Package,
  BarChart3,
  Settings,
  Bell,
  TrendingUp,
  UserPlus,
  CalendarPlus,
  FileText
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from 'recharts';

export default function App() {
  const navItems = [
    { icon: LayoutDashboard, label: 'Dashboard', active: true },
    { icon: Users, label: 'Socios', active: false },
    { icon: CreditCard, label: 'Membresías', active: false },
    { icon: UserCog, label: 'Entrenadores', active: false },
    { icon: Dumbbell, label: 'Clases', active: false },
    { icon: Package, label: 'Inventario', active: false },
    { icon: BarChart3, label: 'Reportes', active: false },
    { icon: Settings, label: 'Configuración', active: false },
  ];

  const kpiData = [
    { label: 'Total Socios', value: '248', icon: Users },
    { label: 'Membresías Activas', value: '193', icon: CreditCard },
    { label: 'Ingresos del Mes', value: '$4.2M COP', icon: TrendingUp },
    { label: 'Tasa de Deserción', value: '8%', icon: BarChart3 },
  ];

  const attendanceData = [
    { day: 'Lun', count: 145 },
    { day: 'Mar', count: 168 },
    { day: 'Mié', count: 152 },
    { day: 'Jue', count: 179 },
    { day: 'Vie', count: 191 },
    { day: 'Sáb', count: 98 },
    { day: 'Dom', count: 67 },
  ];

  const expiringMemberships = [
    { name: 'Carlos Mendoza', plan: 'Premium', days: 3 },
    { name: 'Ana García', plan: 'Básico', days: 7 },
    { name: 'Luis Ramírez', plan: 'VIP', days: 10 },
    { name: 'María Torres', plan: 'Premium', days: 14 },
    { name: 'José Hernández', plan: 'Básico', days: 18 },
  ];

  const quickActions = [
    { icon: UserPlus, label: 'Registrar Socio' },
    { icon: CreditCard, label: 'Asignar Membresía' },
    { icon: CalendarPlus, label: 'Nueva Clase' },
    { icon: FileText, label: 'Ver Reportes' },
  ];

  const getPlanColor = (plan: string) => {
    switch (plan) {
      case 'VIP':
        return 'bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8]';
      case 'Premium':
        return 'bg-[#7d2ae8]';
      case 'Básico':
        return 'bg-[#00f2ff]/50';
      default:
        return 'bg-[#94a3b8]';
    }
  };

  const getDaysColor = (days: number) => {
    if (days <= 5) return 'text-red-400';
    if (days <= 10) return 'text-yellow-400';
    return 'text-[#00f2ff]';
  };

  return (
    <div className="size-full bg-[#050508] text-white overflow-hidden" style={{ fontFamily: 'Inter, sans-serif' }}>
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-full w-[240px] border-r border-white/[0.08] bg-black/20 p-6">
        <div className="mb-8">
          <h1
            className="text-2xl bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] bg-clip-text text-transparent"
            style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800 }}
          >
            GymFit
          </h1>
        </div>
        <nav className="space-y-2">
          {navItems.map((item, index) => (
            <button
              key={index}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-full transition-all ${
                item.active
                  ? 'bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] text-white'
                  : 'text-[#94a3b8] hover:text-white hover:bg-white/[0.05]'
              }`}
            >
              <item.icon size={20} />
              <span className="text-sm font-medium">{item.label}</span>
            </button>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <div className="ml-[240px] h-full overflow-y-auto">
        {/* Top Bar */}
        <header className="sticky top-0 z-10 border-b border-white/[0.08] bg-[#050508]/80 backdrop-blur-xl px-8 py-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl">Bienvenido, <span className="font-semibold">Admin</span></h2>
            <div className="flex items-center gap-4">
              <button className="relative p-2 rounded-full bg-white/[0.03] border border-white/[0.08] hover:bg-white/[0.05] transition-all">
                <Bell size={20} />
                <span className="absolute top-1 right-1 w-2 h-2 bg-[#00f2ff] rounded-full"></span>
              </button>
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8]"></div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <main className="p-8 space-y-6">
          {/* KPI Cards */}
          <div className="grid grid-cols-4 gap-6">
            {kpiData.map((kpi, index) => (
              <div
                key={index}
                className="p-6 rounded-[20px] bg-white/[0.03] border border-white/[0.08] backdrop-blur-sm"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="p-3 rounded-xl bg-gradient-to-br from-[#00f2ff] to-[#7d2ae8]">
                    <kpi.icon size={20} className="text-white" />
                  </div>
                </div>
                <p className="text-[#94a3b8] text-sm mb-2">{kpi.label}</p>
                <p className="text-3xl font-semibold text-white">{kpi.value}</p>
              </div>
            ))}
          </div>

          {/* Charts and Lists Row */}
          <div className="grid grid-cols-2 gap-6">
            {/* Attendance Chart */}
            <div className="p-6 rounded-[20px] bg-white/[0.03] border border-white/[0.08] backdrop-blur-sm">
              <h3 className="text-lg font-semibold mb-6">Asistencia Semanal</h3>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={attendanceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                  <XAxis
                    dataKey="day"
                    stroke="#94a3b8"
                    tick={{ fill: '#94a3b8', fontSize: 12 }}
                  />
                  <YAxis
                    stroke="#94a3b8"
                    tick={{ fill: '#94a3b8', fontSize: 12 }}
                  />
                  <Bar
                    dataKey="count"
                    fill="url(#gradient)"
                    radius={[8, 8, 0, 0]}
                  />
                  <defs>
                    <linearGradient id="gradient" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor="#00f2ff" />
                      <stop offset="100%" stopColor="#7d2ae8" />
                    </linearGradient>
                  </defs>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Expiring Memberships List */}
            <div className="p-6 rounded-[20px] bg-white/[0.03] border border-white/[0.08] backdrop-blur-sm">
              <h3 className="text-lg font-semibold mb-6">Membresías por Vencer</h3>
              <div className="space-y-4">
                {expiringMemberships.map((member, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 rounded-xl bg-white/[0.02] border border-white/[0.05] hover:bg-white/[0.05] transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#00f2ff]/30 to-[#7d2ae8]/30 flex items-center justify-center text-sm font-semibold">
                        {member.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <p className="font-medium text-sm">{member.name}</p>
                        <span className={`inline-block px-2 py-0.5 rounded-full text-xs ${getPlanColor(member.plan)} text-white mt-1`}>
                          {member.plan}
                        </span>
                      </div>
                    </div>
                    <div className={`text-sm font-semibold ${getDaysColor(member.days)}`}>
                      {member.days}d
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="p-6 rounded-[20px] bg-white/[0.03] border border-white/[0.08] backdrop-blur-sm">
            <h3 className="text-lg font-semibold mb-6">Acciones Rápidas</h3>
            <div className="grid grid-cols-4 gap-4">
              {quickActions.map((action, index) => (
                <button
                  key={index}
                  className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.08] hover:border-[#00f2ff] hover:bg-white/[0.05] transition-all group"
                >
                  <div className="flex flex-col items-center gap-3">
                    <div className="p-3 rounded-lg bg-gradient-to-br from-[#00f2ff]/20 to-[#7d2ae8]/20 group-hover:from-[#00f2ff]/40 group-hover:to-[#7d2ae8]/40 transition-all">
                      <action.icon size={24} className="text-[#00f2ff]" />
                    </div>
                    <span className="text-sm font-medium text-[#94a3b8] group-hover:text-white transition-colors">
                      {action.label}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}