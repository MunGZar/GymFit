
  # Design GymFit Landing Page

  This is a code bundle for Design GymFit Landing Page. The original project is available at https://www.figma.com/design/kzPMB0WRGp4hj9t2UF5iS1/Design-GymFit-Landing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  