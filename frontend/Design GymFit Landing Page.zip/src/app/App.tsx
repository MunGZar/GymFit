import { Play, Check } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-[#050508] text-white relative overflow-x-hidden" style={{ fontFamily: 'Inter, sans-serif' }}>
      {/* Decorative blobs */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-[#00f2ff] rounded-full opacity-15 blur-[80px] pointer-events-none"></div>
      <div className="absolute bottom-0 right-0 w-[600px] h-[600px] bg-[#7d2ae8] rounded-full opacity-15 blur-[80px] pointer-events-none"></div>

      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#050508]/80 backdrop-blur-md border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] bg-clip-text text-transparent" style={{ fontFamily: 'Outfit, sans-serif', fontSize: '24px', fontWeight: 800 }}>
            GymFit
          </div>

          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-white/80 hover:text-white transition-colors">Características</a>
            <a href="#plans" className="text-white/80 hover:text-white transition-colors">Planes</a>
            <a href="#access" className="text-white/80 hover:text-white transition-colors">Acceso</a>
          </div>

          <div className="flex items-center gap-4">
            <button className="px-5 py-2 border border-[#00f2ff] text-[#00f2ff] rounded-lg hover:bg-[#00f2ff]/10 transition-all">
              Iniciar Sesión
            </button>
            <button className="px-5 py-2 bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] rounded-lg hover:opacity-90 transition-opacity">
              Comenzar gratis
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center px-6 pt-24 relative">
        {/* Grid pattern overlay */}
        <div className="absolute inset-0 opacity-5" style={{
          backgroundImage: 'linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)',
          backgroundSize: '50px 50px'
        }}></div>

        <div className="max-w-4xl text-center relative z-10">
          <h1 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '64px', fontWeight: 800, lineHeight: '1.1' }} className="mb-6">
            Administra tu gimnasio<br />
            <span className="bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] bg-clip-text text-transparent">
              sin complicaciones.
            </span>
          </h1>

          <p className="text-[#94a3b8] mb-8 max-w-2xl mx-auto" style={{ fontSize: '18px' }}>
            FIT-CONTROL centraliza socios, membresías, pagos y accesos en una sola plataforma web. Simple, rápido y seguro.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 mb-12">
            <button className="px-8 py-4 bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] rounded-lg hover:opacity-90 transition-opacity flex items-center gap-2">
              Solicitar Demo
            </button>
            <button className="px-8 py-4 border border-white/20 rounded-lg hover:bg-white/5 transition-all flex items-center gap-2">
              <Play className="w-5 h-5" />
              Ver cómo funciona
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-8 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-[#00f2ff] rounded-full"></div>
              <span className="text-white/60">248 socios gestionados</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-[#00f2ff] rounded-full"></div>
              <span className="text-white/60">99.9% disponibilidad</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-[#00f2ff] rounded-full"></div>
              <span className="text-white/60">Datos protegidos</span>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 px-6 relative">
        <div className="max-w-7xl mx-auto">
          <h2 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '48px', fontWeight: 800 }} className="text-center mb-16">
            Todo lo que necesita tu gimnasio
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: 'Gestión de Socios',
                desc: 'Registra, edita y controla el ciclo de vida de cada miembro.',
                icon: '👥'
              },
              {
                title: 'Control de Membresías',
                desc: 'Planes Básico, Premium, VIP y Corporativo con vencimiento automático.',
                icon: '💳'
              },
              {
                title: 'Control de Acceso',
                desc: 'Validación en tiempo real al ingreso. Respuesta visual verde/rojo.',
                icon: '🚪'
              },
              {
                title: 'Rutinas de Entrenamiento',
                desc: 'Entrenadores asignan y actualizan planes personalizados.',
                icon: '💪'
              },
              {
                title: 'Gestión de Inventario',
                desc: 'Control de suplementos y cafetería con alertas de stock mínimo.',
                icon: '📦'
              },
              {
                title: 'Reportes y Estadísticas',
                desc: 'Exporta informes de asistencia e ingresos en PDF y Excel.',
                icon: '📊'
              }
            ].map((feature, idx) => (
              <div
                key={idx}
                className="p-8 rounded-[20px] backdrop-blur-[12px] border border-white/8"
                style={{ background: 'rgba(255, 255, 255, 0.03)' }}
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] flex items-center justify-center mb-4 text-2xl">
                  {feature.icon}
                </div>
                <h3 className="mb-3">{feature.title}</h3>
                <p className="text-[#94a3b8]">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Plans Section */}
      <section id="plans" className="py-24 px-6 relative">
        <div className="max-w-7xl mx-auto">
          <h2 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '48px', fontWeight: 800 }} className="text-center mb-16">
            Elige el plan ideal
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Básico */}
            <div
              className="p-8 rounded-[20px] backdrop-blur-[12px] border border-white/8 flex flex-col"
              style={{ background: 'rgba(255, 255, 255, 0.03)' }}
            >
              <h3 className="mb-2">Básico</h3>
              <div className="mb-6">
                <span className="text-4xl">$49</span>
                <span className="text-[#94a3b8]">/mes</span>
              </div>
              <ul className="space-y-3 mb-8 flex-1">
                <li className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-[#00f2ff] flex-shrink-0 mt-0.5" />
                  <span className="text-[#94a3b8]">Hasta 100 socios</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-[#00f2ff] flex-shrink-0 mt-0.5" />
                  <span className="text-[#94a3b8]">Gestión de membresías</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-[#00f2ff] flex-shrink-0 mt-0.5" />
                  <span className="text-[#94a3b8]">Control de acceso</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-[#00f2ff] flex-shrink-0 mt-0.5" />
                  <span className="text-[#94a3b8]">Reportes básicos</span>
                </li>
              </ul>
              <button className="w-full py-3 border border-white/20 rounded-lg hover:bg-white/5 transition-all">
                Empezar
              </button>
            </div>

            {/* Premium */}
            <div
              className="p-8 rounded-[20px] backdrop-blur-[12px] border-2 flex flex-col relative"
              style={{
                background: 'rgba(255, 255, 255, 0.03)',
                borderImage: 'linear-gradient(135deg, #00f2ff, #7d2ae8) 1'
              }}
            >
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] rounded-full text-sm">
                Más popular
              </div>
              <h3 className="mb-2">Premium</h3>
              <div className="mb-6">
                <span className="text-4xl">$99</span>
                <span className="text-[#94a3b8]">/mes</span>
              </div>
              <ul className="space-y-3 mb-8 flex-1">
                <li className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-[#00f2ff] flex-shrink-0 mt-0.5" />
                  <span className="text-[#94a3b8]">Socios ilimitados</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-[#00f2ff] flex-shrink-0 mt-0.5" />
                  <span className="text-[#94a3b8]">Todas las funciones</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-[#00f2ff] flex-shrink-0 mt-0.5" />
                  <span className="text-[#94a3b8]">Rutinas personalizadas</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-[#00f2ff] flex-shrink-0 mt-0.5" />
                  <span className="text-[#94a3b8]">Inventario completo</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-[#00f2ff] flex-shrink-0 mt-0.5" />
                  <span className="text-[#94a3b8]">Reportes avanzados</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-[#00f2ff] flex-shrink-0 mt-0.5" />
                  <span className="text-[#94a3b8]">Soporte prioritario</span>
                </li>
              </ul>
              <button className="w-full py-3 bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] rounded-lg hover:opacity-90 transition-opacity">
                Empezar
              </button>
            </div>

            {/* VIP / Corporativo */}
            <div
              className="p-8 rounded-[20px] backdrop-blur-[12px] border border-white/8 flex flex-col"
              style={{ background: 'rgba(255, 255, 255, 0.03)' }}
            >
              <h3 className="mb-2">VIP / Corporativo</h3>
              <div className="mb-6">
                <span className="text-4xl">$249</span>
                <span className="text-[#94a3b8]">/mes</span>
              </div>
              <ul className="space-y-3 mb-8 flex-1">
                <li className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-[#00f2ff] flex-shrink-0 mt-0.5" />
                  <span className="text-[#94a3b8]">Múltiples ubicaciones</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-[#00f2ff] flex-shrink-0 mt-0.5" />
                  <span className="text-[#94a3b8]">API personalizada</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-[#00f2ff] flex-shrink-0 mt-0.5" />
                  <span className="text-[#94a3b8]">Integraciones custom</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-[#00f2ff] flex-shrink-0 mt-0.5" />
                  <span className="text-[#94a3b8]">Soporte 24/7</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-[#00f2ff] flex-shrink-0 mt-0.5" />
                  <span className="text-[#94a3b8]">Capacitación incluida</span>
                </li>
              </ul>
              <button className="w-full py-3 border border-white/20 rounded-lg hover:bg-white/5 transition-all">
                Contactar
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-24 px-6 relative">
        <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
          <div className="w-[400px] h-[400px] bg-[#00f2ff] rounded-full opacity-20 blur-[100px]"></div>
          <div className="w-[400px] h-[400px] bg-[#7d2ae8] rounded-full opacity-20 blur-[100px] ml-20"></div>
        </div>

        <div className="max-w-4xl mx-auto text-center relative z-10">
          <h2 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '48px', fontWeight: 800 }} className="mb-6">
            <span className="bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] bg-clip-text text-transparent">
              ¿Listo para transformar la gestión de tu gimnasio?
            </span>
          </h2>
          <p className="text-[#94a3b8] mb-8 max-w-2xl mx-auto">
            Únete a cientos de gimnasios que ya optimizaron sus operaciones con FIT-CONTROL.
          </p>
          <button className="px-10 py-4 bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] rounded-lg hover:opacity-90 transition-opacity text-lg">
            Comenzar ahora
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-white/5">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] bg-clip-text text-transparent" style={{ fontFamily: 'Outfit, sans-serif', fontSize: '20px', fontWeight: 800 }}>
            GymFit
          </div>

          <div className="flex items-center gap-8">
            <a href="#features" className="text-white/60 hover:text-white transition-colors">Características</a>
            <a href="#plans" className="text-white/60 hover:text-white transition-colors">Planes</a>
            <a href="#access" className="text-white/60 hover:text-white transition-colors">Acceso</a>
          </div>

          <div className="text-[#94a3b8] text-sm">
            © 2026 FIT-CONTROL — Instituto Tecnológico del Putumayo
          </div>
        </div>
      </footer>
    </div>
  );
}
