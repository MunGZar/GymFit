import { RefreshCw, Pencil, Trash2, ChevronLeft, ChevronRight } from 'lucide-react';

interface Membership {
  id: string;
  member: {
    name: string;
    avatar: string;
    id: string;
  };
  plan: {
    name: string;
    color: string;
  };
  startDate: string;
  expiryDate: string;
  daysUntilExpiry: number;
  status: 'Activa' | 'Vencida' | 'Cancelada' | 'Renovada';
  payment: 'Pagado' | 'Pendiente';
}

const memberships: Membership[] = [
  {
    id: '001',
    member: { name: 'Carlos Mendoza', avatar: 'CM', id: 'SOC-1245' },
    plan: { name: 'Premium', color: 'cyan' },
    startDate: '2026-03-25',
    expiryDate: '2026-04-25',
    daysUntilExpiry: 0,
    status: 'Activa',
    payment: 'Pagado',
  },
  {
    id: '002',
    member: { name: 'Ana Rodríguez', avatar: 'AR', id: 'SOC-1198' },
    plan: { name: 'VIP', color: 'violet' },
    startDate: '2026-04-01',
    expiryDate: '2026-05-01',
    daysUntilExpiry: 6,
    status: 'Activa',
    payment: 'Pagado',
  },
  {
    id: '003',
    member: { name: 'Diego Silva', avatar: 'DS', id: 'SOC-1302' },
    plan: { name: 'Básico', color: 'gray' },
    startDate: '2026-02-20',
    expiryDate: '2026-03-20',
    daysUntilExpiry: -36,
    status: 'Vencida',
    payment: 'Pendiente',
  },
  {
    id: '004',
    member: { name: 'María López', avatar: 'ML', id: 'SOC-1089' },
    plan: { name: 'Premium', color: 'cyan' },
    startDate: '2026-04-10',
    expiryDate: '2026-05-10',
    daysUntilExpiry: 15,
    status: 'Activa',
    payment: 'Pagado',
  },
  {
    id: '005',
    member: { name: 'Tech Solutions SAS', avatar: 'TS', id: 'CORP-042' },
    plan: { name: 'Corporativo', color: 'gradient' },
    startDate: '2026-04-01',
    expiryDate: '2026-05-01',
    daysUntilExpiry: 6,
    status: 'Activa',
    payment: 'Pagado',
  },
  {
    id: '006',
    member: { name: 'Luis Fernández', avatar: 'LF', id: 'SOC-1456' },
    plan: { name: 'VIP', color: 'violet' },
    startDate: '2026-03-15',
    expiryDate: '2026-04-15',
    daysUntilExpiry: -10,
    status: 'Renovada',
    payment: 'Pagado',
  },
  {
    id: '007',
    member: { name: 'Sandra Martínez', avatar: 'SM', id: 'SOC-1334' },
    plan: { name: 'Básico', color: 'gray' },
    startDate: '2026-03-01',
    expiryDate: '2026-03-31',
    daysUntilExpiry: -25,
    status: 'Cancelada',
    payment: 'Pagado',
  },
];

function getExpiryColor(days: number) {
  if (days < 0) return 'text-red-500';
  if (days < 5) return 'text-red-400';
  if (days <= 15) return 'text-amber-400';
  return 'text-green-400';
}

function getPlanBadgeClass(color: string) {
  if (color === 'cyan') return 'bg-[#00f2ff]/20 border-[#00f2ff]/40 text-[#00f2ff]';
  if (color === 'violet') return 'bg-[#7d2ae8]/20 border-[#7d2ae8]/40 text-[#7d2ae8]';
  if (color === 'gradient')
    return 'bg-gradient-to-r from-[#00f2ff]/20 to-[#7d2ae8]/20 border-[#00f2ff]/40 text-white';
  return 'bg-gray-500/20 border-gray-500/40 text-gray-300';
}

function getStatusBadgeClass(status: string) {
  if (status === 'Activa') return 'bg-green-500/20 border-green-500/40 text-green-400';
  if (status === 'Vencida') return 'bg-red-500/20 border-red-500/40 text-red-400';
  if (status === 'Cancelada') return 'bg-gray-500/20 border-gray-500/40 text-gray-300';
  if (status === 'Renovada') return 'bg-[#00f2ff]/20 border-[#00f2ff]/40 text-[#00f2ff]';
  return '';
}

function getPaymentBadgeClass(payment: string) {
  if (payment === 'Pagado') return 'bg-green-500/20 text-green-400';
  return 'bg-amber-500/20 text-amber-400';
}

export function MembershipTable() {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3">
        <input
          type="text"
          placeholder="Buscar socio..."
          className="flex-1 min-w-[240px] bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white font-['Inter'] text-sm placeholder:text-[#94a3b8]/50 focus:outline-none focus:border-[#00f2ff]/50 transition-colors"
        />
        <select className="bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white font-['Inter'] text-sm focus:outline-none focus:border-[#00f2ff]/50 transition-colors">
          <option>Estado — Todos</option>
          <option>Activa</option>
          <option>Vencida</option>
          <option>Cancelada</option>
          <option>Renovada</option>
        </select>
        <select className="bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white font-['Inter'] text-sm focus:outline-none focus:border-[#00f2ff]/50 transition-colors">
          <option>Plan — Todos</option>
          <option>Básico</option>
          <option>Premium</option>
          <option>VIP</option>
          <option>Corporativo</option>
        </select>
        <input
          type="text"
          placeholder="Fecha de vencimiento"
          className="bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white font-['Inter'] text-sm placeholder:text-[#94a3b8]/50 focus:outline-none focus:border-[#00f2ff]/50 transition-colors"
        />
      </div>

      <div className="bg-white/[0.03] border border-white/[0.08] rounded-[20px] backdrop-blur-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/5">
                <th className="text-left px-6 py-4 text-xs font-['Inter'] font-semibold text-[#94a3b8] uppercase tracking-wider">
                  Socio
                </th>
                <th className="text-left px-6 py-4 text-xs font-['Inter'] font-semibold text-[#94a3b8] uppercase tracking-wider">
                  Plan
                </th>
                <th className="text-left px-6 py-4 text-xs font-['Inter'] font-semibold text-[#94a3b8] uppercase tracking-wider">
                  Fecha inicio
                </th>
                <th className="text-left px-6 py-4 text-xs font-['Inter'] font-semibold text-[#94a3b8] uppercase tracking-wider">
                  Fecha vencimiento
                </th>
                <th className="text-left px-6 py-4 text-xs font-['Inter'] font-semibold text-[#94a3b8] uppercase tracking-wider">
                  Estado
                </th>
                <th className="text-left px-6 py-4 text-xs font-['Inter'] font-semibold text-[#94a3b8] uppercase tracking-wider">
                  Pago
                </th>
                <th className="text-left px-6 py-4 text-xs font-['Inter'] font-semibold text-[#94a3b8] uppercase tracking-wider">
                  Acciones
                </th>
              </tr>
            </thead>
            <tbody>
              {memberships.map((membership, index) => (
                <tr
                  key={membership.id}
                  className={`${
                    index !== memberships.length - 1 ? 'border-b border-white/5' : ''
                  } hover:bg-white/[0.02] transition-colors`}
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#00f2ff] to-[#7d2ae8] flex items-center justify-center text-white font-['Inter'] font-semibold text-sm">
                        {membership.member.avatar}
                      </div>
                      <div>
                        <div className="text-sm font-['Inter'] font-medium text-white">
                          {membership.member.name}
                        </div>
                        <div className="text-xs font-['Inter'] text-[#94a3b8]">
                          {membership.member.id}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`inline-block px-3 py-1 rounded-full text-xs font-['Inter'] font-semibold border ${getPlanBadgeClass(
                        membership.plan.color
                      )}`}
                    >
                      {membership.plan.name}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm font-['Inter'] text-white">
                      {membership.startDate}
                    </div>
                    <div className="text-xs font-['Inter'] text-[#94a3b8]">
                      hace{' '}
                      {Math.abs(
                        Math.floor(
                          (new Date().getTime() - new Date(membership.startDate).getTime()) /
                            (1000 * 60 * 60 * 24)
                        )
                      )}{' '}
                      días
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm font-['Inter'] text-white">
                      {membership.expiryDate}
                    </div>
                    <div
                      className={`text-xs font-['Inter'] font-semibold ${getExpiryColor(
                        membership.daysUntilExpiry
                      )}`}
                    >
                      {membership.daysUntilExpiry < 0
                        ? `Vencida hace ${Math.abs(membership.daysUntilExpiry)} días`
                        : membership.daysUntilExpiry === 0
                        ? 'Vence hoy'
                        : `${membership.daysUntilExpiry} días restantes`}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`inline-block px-3 py-1 rounded-full text-xs font-['Inter'] font-semibold border ${getStatusBadgeClass(
                        membership.status
                      )}`}
                    >
                      {membership.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`inline-block px-2 py-1 rounded text-xs font-['Inter'] font-semibold ${getPaymentBadgeClass(
                        membership.payment
                      )}`}
                    >
                      {membership.payment}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button className="p-2 rounded-lg text-[#00f2ff] hover:bg-[#00f2ff]/10 transition-colors">
                        <RefreshCw size={16} />
                      </button>
                      <button className="p-2 rounded-lg text-[#94a3b8] hover:bg-white/5 hover:text-white transition-colors">
                        <Pencil size={16} />
                      </button>
                      <button className="p-2 rounded-lg text-[#94a3b8] hover:bg-red-500/10 hover:text-red-400 transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-center gap-2 px-6 py-4 border-t border-white/5">
          <button className="p-2 rounded-lg text-[#94a3b8] hover:bg-white/5 hover:text-white transition-colors">
            <ChevronLeft size={16} />
          </button>
          <button className="px-3 py-1 rounded-lg bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] text-white font-['Inter'] font-semibold text-sm">
            1
          </button>
          <button className="px-3 py-1 rounded-lg text-[#94a3b8] hover:bg-white/5 hover:text-white font-['Inter'] font-semibold text-sm transition-colors">
            2
          </button>
          <button className="px-3 py-1 rounded-lg text-[#94a3b8] hover:bg-white/5 hover:text-white font-['Inter'] font-semibold text-sm transition-colors">
            3
          </button>
          <button className="p-2 rounded-lg text-[#94a3b8] hover:bg-white/5 hover:text-white transition-colors">
            <ChevronRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
