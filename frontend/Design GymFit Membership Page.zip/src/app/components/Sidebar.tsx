import { Home, Users, CreditCard, BarChart3, Settings, Dumbbell } from 'lucide-react';

export function Sidebar() {
  const navItems = [
    { icon: Home, label: 'Dashboard', active: false },
    { icon: Users, label: 'Socios', active: false },
    { icon: CreditCard, label: 'Membresías', active: true },
    { icon: Dumbbell, label: 'Clases', active: false },
    { icon: BarChart3, label: 'Reportes', active: false },
    { icon: Settings, label: 'Configuración', active: false },
  ];

  return (
    <div className="fixed left-0 top-0 h-full w-[240px] bg-black/40 border-r border-white/8 backdrop-blur-xl">
      <div className="p-6">
        <div className="mb-8">
          <h1 className="text-2xl font-['Outfit'] font-extrabold text-white mb-1">
            GymFit
          </h1>
          <div className="text-xs font-['Inter'] font-semibold bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] bg-clip-text text-transparent">
            FIT-CONTROL
          </div>
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.label}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-['Inter'] font-medium text-sm transition-all ${
                  item.active
                    ? 'bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] text-white shadow-lg shadow-cyan-500/20'
                    : 'text-[#94a3b8] hover:bg-white/5 hover:text-white'
                }`}
              >
                <Icon size={18} />
                {item.label}
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
