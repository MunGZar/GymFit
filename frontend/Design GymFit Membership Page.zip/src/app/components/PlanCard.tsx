import { Check, Pencil } from 'lucide-react';

interface PlanCardProps {
  name: string;
  price: string;
  priceColor: string;
  duration: string;
  features: string[];
  activeMembers: string;
  topBarColor: string;
  badge?: string;
  featured?: boolean;
}

export function PlanCard({
  name,
  price,
  priceColor,
  duration,
  features,
  activeMembers,
  topBarColor,
  badge,
  featured,
}: PlanCardProps) {
  return (
    <div
      className={`relative bg-white/[0.03] border border-white/[0.08] rounded-[20px] backdrop-blur-xl overflow-hidden ${
        featured ? 'scale-105' : ''
      }`}
    >
      <div className={`h-1 ${topBarColor}`} />

      {badge && (
        <div className="absolute top-4 right-4 bg-[#00f2ff]/20 border border-[#00f2ff]/40 text-[#00f2ff] text-xs font-['Inter'] font-semibold px-3 py-1 rounded-full">
          {badge}
        </div>
      )}

      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <h3 className="text-xl font-['Outfit'] font-extrabold text-white">
            {name}
          </h3>
          <button className="text-[#94a3b8] hover:text-white transition-colors">
            <Pencil size={16} />
          </button>
        </div>

        <div className={`text-lg font-['Inter'] font-semibold mb-1 ${priceColor}`}>
          {price}
        </div>
        <div className="text-sm font-['Inter'] text-[#94a3b8] mb-6">
          {duration}
        </div>

        <div className="space-y-3 mb-6">
          {features.map((feature, index) => (
            <div key={index} className="flex items-start gap-2">
              <Check size={16} className="text-[#00f2ff] mt-0.5 flex-shrink-0" />
              <span className="text-[13px] font-['Inter'] text-[#94a3b8] leading-snug">
                {feature}
              </span>
            </div>
          ))}
        </div>

        <div className="text-xs font-['Inter'] text-[#94a3b8]">
          {activeMembers}
        </div>
      </div>
    </div>
  );
}
