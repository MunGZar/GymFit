import { X } from 'lucide-react';
import { useState } from 'react';

interface CreatePlanModalProps {
  onClose: () => void;
}

export function CreatePlanModal({ onClose }: CreatePlanModalProps) {
  const [benefits, setBenefits] = useState<string[]>([]);
  const [benefitInput, setBenefitInput] = useState('');
  const [selectedColor, setSelectedColor] = useState('cyan');

  const handleAddBenefit = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && benefitInput.trim()) {
      e.preventDefault();
      setBenefits([...benefits, benefitInput.trim()]);
      setBenefitInput('');
    }
  };

  const removeBenefit = (index: number) => {
    setBenefits(benefits.filter((_, i) => i !== index));
  };

  const colors = [
    { id: 'gray', class: 'bg-gray-500' },
    { id: 'cyan', class: 'bg-[#00f2ff]' },
    { id: 'violet', class: 'bg-[#7d2ae8]' },
    { id: 'gradient', class: 'bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8]' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />

      <div className="relative w-full max-w-[480px] mx-4 bg-white/[0.03] border border-white/[0.08] rounded-[20px] backdrop-blur-[20px] p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-['Outfit'] font-extrabold text-white">
            Nuevo Plan de Membresía
          </h2>
          <button
            onClick={onClose}
            className="text-[#94a3b8] hover:text-white transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-['Inter'] font-medium text-[#94a3b8] mb-2">
              Nombre del plan
            </label>
            <input
              type="text"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white font-['Inter'] placeholder:text-[#94a3b8]/50 focus:outline-none focus:border-[#00f2ff]/50 transition-colors"
              placeholder="Ej: Premium Plus"
            />
          </div>

          <div>
            <label className="block text-sm font-['Inter'] font-medium text-[#94a3b8] mb-2">
              Precio mensual en COP
            </label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#94a3b8]">
                $
              </span>
              <input
                type="number"
                className="w-full bg-white/5 border border-white/10 rounded-xl pl-8 pr-4 py-3 text-white font-['Inter'] placeholder:text-[#94a3b8]/50 focus:outline-none focus:border-[#00f2ff]/50 transition-colors"
                placeholder="150000"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-['Inter'] font-medium text-[#94a3b8] mb-2">
              Duración en días
            </label>
            <input
              type="number"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white font-['Inter'] placeholder:text-[#94a3b8]/50 focus:outline-none focus:border-[#00f2ff]/50 transition-colors"
              placeholder="30"
            />
          </div>

          <div>
            <label className="block text-sm font-['Inter'] font-medium text-[#94a3b8] mb-2">
              Descripción corta
            </label>
            <textarea
              rows={3}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white font-['Inter'] placeholder:text-[#94a3b8]/50 focus:outline-none focus:border-[#00f2ff]/50 transition-colors resize-none"
              placeholder="Describe los principales beneficios del plan..."
            />
          </div>

          <div>
            <label className="block text-sm font-['Inter'] font-medium text-[#94a3b8] mb-2">
              Beneficios incluidos
            </label>
            <input
              type="text"
              value={benefitInput}
              onChange={(e) => setBenefitInput(e.target.value)}
              onKeyDown={handleAddBenefit}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white font-['Inter'] placeholder:text-[#94a3b8]/50 focus:outline-none focus:border-[#00f2ff]/50 transition-colors"
              placeholder="Escribe un beneficio y presiona Enter"
            />
            {benefits.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-3">
                {benefits.map((benefit, index) => (
                  <div
                    key={index}
                    className="flex items-center gap-2 bg-[#00f2ff]/20 border border-[#00f2ff]/40 text-[#00f2ff] text-sm font-['Inter'] px-3 py-1.5 rounded-full"
                  >
                    <span>{benefit}</span>
                    <button
                      onClick={() => removeBenefit(index)}
                      className="hover:text-white transition-colors"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm font-['Inter'] font-medium text-[#94a3b8] mb-2">
              Color de identificación
            </label>
            <div className="flex gap-3">
              {colors.map((color) => (
                <button
                  key={color.id}
                  onClick={() => setSelectedColor(color.id)}
                  className={`w-10 h-10 rounded-full ${color.class} ${
                    selectedColor === color.id
                      ? 'ring-2 ring-white ring-offset-2 ring-offset-[#050508]'
                      : 'opacity-50 hover:opacity-100'
                  } transition-all`}
                />
              ))}
            </div>
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button
            onClick={onClose}
            className="flex-1 px-6 py-3 rounded-xl border border-white/10 text-white font-['Inter'] font-medium hover:bg-white/5 transition-colors"
          >
            Cancelar
          </button>
          <button className="flex-1 px-6 py-3 rounded-xl bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] text-white font-['Inter'] font-semibold hover:shadow-lg hover:shadow-cyan-500/20 transition-all">
            Guardar Plan
          </button>
        </div>
      </div>
    </div>
  );
}
