import { useState } from 'react';
import { Plus } from 'lucide-react';
import { Sidebar } from './components/Sidebar';
import { PlanCard } from './components/PlanCard';
import { MembershipTable } from './components/MembershipTable';
import { CreatePlanModal } from './components/CreatePlanModal';

export default function App() {
  const [showModal, setShowModal] = useState(true);

  return (
    <div className="min-h-screen bg-[#050508] font-['Inter']">
      <Sidebar />

      <div className="ml-[240px] p-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-[28px] font-['Outfit'] font-extrabold text-white">
            Gestión de Membresías
          </h1>
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] text-white font-['Inter'] font-semibold hover:shadow-lg hover:shadow-cyan-500/20 transition-all"
          >
            <Plus size={20} />
            Crear Plan
          </button>
        </div>

        <div className="mb-12">
          <h2 className="text-base font-['Inter'] font-semibold text-[#94a3b8] mb-4">
            Planes disponibles
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <PlanCard
              name="Básico"
              price="$80.000 COP / mes"
              priceColor="text-[#00f2ff]"
              duration="30 días"
              features={[
                'Acceso a sala de musculación',
                'Horario estándar (6am - 8pm)',
                'Sin entrenador asignado',
              ]}
              activeMembers="62 socios activos"
              topBarColor="bg-gradient-to-r from-gray-400 to-gray-500"
            />

            <PlanCard
              name="Premium"
              price="$150.000 COP / mes"
              priceColor="text-[#00f2ff]"
              duration="30 días"
              features={[
                'Todo lo del plan Básico',
                'Entrenador asignado',
                'Acceso a clases grupales',
                'Evaluación física inicial',
              ]}
              activeMembers="98 socios activos"
              topBarColor="bg-gradient-to-r from-[#00f2ff] to-[#00d4dd]"
              badge="Más vendido"
              featured
            />

            <PlanCard
              name="VIP"
              price="$250.000 COP / mes"
              priceColor="text-[#7d2ae8]"
              duration="30 días"
              features={[
                'Todo lo del plan Premium',
                'Acceso ilimitado 24/7',
                'Suplementos incluidos (1 por mes)',
                'Zona de recuperación exclusiva',
              ]}
              activeMembers="28 socios activos"
              topBarColor="bg-gradient-to-r from-[#7d2ae8] to-[#9d4ef8]"
            />

            <PlanCard
              name="Corporativo"
              price="$800.000 COP / mes"
              priceColor="bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8] bg-clip-text text-transparent"
              duration="30 días"
              features={[
                'Hasta 10 empleados de una empresa',
                'Entrenador dedicado',
                'Reportes de progreso grupal',
                'Facturación empresarial',
              ]}
              activeMembers="5 empresas activas"
              topBarColor="bg-gradient-to-r from-[#00f2ff] to-[#7d2ae8]"
            />
          </div>
        </div>

        <div>
          <h2 className="text-base font-['Inter'] font-semibold text-[#94a3b8] mb-4">
            Membresías asignadas
          </h2>
          <MembershipTable />
        </div>
      </div>

      {showModal && <CreatePlanModal onClose={() => setShowModal(false)} />}
    </div>
  );
}