
  # Design GymFit Membership Page

  This is a code bundle for Design GymFit Membership Page. The original project is available at https://www.figma.com/design/4MT3bDnZbXvFSZT8Hanjl4/Design-GymFit-Membership-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  